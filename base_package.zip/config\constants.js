export const CONFIG = {
  FIRESTORE_PROJECT_ID: "alt-mvgr", 
  API_ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  DEFAULT_MODEL: "llama-3.2-11b-vision-preview",
  MAX_RETRIES: 3,
  INITIAL_RETRY_DELAY_MS: 2000,
  IMAGE_QUALITY: 40,
  SYSTEM_PROMPT: `You are an elite academic solver. You are given the OCR extracted text of a multiple-choice question.
Your task is to analyze the problem and arrive at the correct option.
CRITICAL: You MUST be concise. Do not write massive paragraphs. Solve the problem directly and quickly to save time.
After reasoning, you MUST output ONLY the final correct option letter inside XML tags.
YOU MUST output exactly like this: <answer>B</answer> at the very end of your response.`
};

export const INJECTED_UID = "%%INJECT_UID_HERE%%";
