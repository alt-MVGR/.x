import { ParserError } from './errors.js';
import { Logger } from './logger.js';

/**
 * Robust text parser that completely ignores JSON.
 * Aggressively extracts A, B, C, D, 1, 2, 3, 4 from model output.
 */
export function extractOption(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    throw new ParserError("Output is not a valid string", { rawText });
  }

  Logger.debug("Parser", "Raw input:", rawText);

  // Look for our strict XML format: <answer>C</answer>
  const match = rawText.match(/<answer>\s*([A-D1-4])\s*<\/answer>/i);
  
  if (match && match[1]) {
    return normalizeOption(match[1]);
  }

  // Extreme Fallback: If the model failed to output XML but output a single character
  const stripped = rawText.trim();
  if (stripped.length === 1 && /^[A-D1-4]$/i.test(stripped)) {
    Logger.warn("Parser", "Model did not output XML, but output a single character.");
    return normalizeOption(stripped);
  }

  throw new ParserError("Could not find <answer>X</answer> tags in the response.", { rawText });
}

function normalizeOption(char) {
  const upper = char.toUpperCase();
  // Map numbers to letters for UI consistency if needed
  const map = { '1': 'A', '2': 'B', '3': 'C', '4': 'D' };
  return { correct: map[upper] || upper };
}
