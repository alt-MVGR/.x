import { Logger } from './logger.js';

/**
 * Parses Retry-After header or applies exponential backoff
 */
export async function withRetry(operation, maxRetries = 3, initialDelay = 2000) {
  let attempt = 0;
  
  while (attempt < maxRetries) {
    try {
      return await operation(attempt);
    } catch (error) {
      attempt++;
      Logger.warn("Retry", `Operation failed (Attempt ${attempt}/${maxRetries}):`, error.message);
      
      if (!error.recoverable || attempt >= maxRetries) {
        throw error;
      }
      
      // If the error is a Rate Limit (429), we want to instantly fallback to the next API key.
      // We should NOT apply a massive exponential backoff delay when we are simply swapping keys.
      let delayMs = 0; 
      
      // Only apply delay if the error explicitly demands a Retry-After that we cannot bypass 
      // (e.g. if we are out of keys, but the loop handles key cycling in orchestrator, so we just want instant swap)
      if (error.retryAfter && attempt >= maxRetries) {
        const parsedSeconds = parseInt(error.retryAfter, 10);
        if (!isNaN(parsedSeconds)) {
          delayMs = parsedSeconds * 1000;
        } else {
          const dateMs = new Date(error.retryAfter).getTime();
          if (!isNaN(dateMs)) {
            delayMs = Math.max(0, dateMs - Date.now());
          }
        }
      }
      
      if (delayMs > 0) {
          Logger.info("Retry", `Waiting ${delayMs}ms before next attempt...`);
          await new Promise(resolve => setTimeout(resolve, delayMs));
      } else {
          Logger.info("Retry", `Instantly falling back to next API key...`);
      }
    }
  }
}
