import { INJECTED_UID } from './config/constants.js';
import { Logger } from './utils/logger.js';
import { withRetry } from './utils/retry.js';
import { getApiKeys } from './firebase/keys.js';
import { getGlobalConfig } from './firebase/config.js';
import { captureScreen } from './background/capture.js';
import { runConsensusPipeline } from './api/orchestrator.js';
import { Messenger } from './ui/messenger.js';

Logger.info("System", "Background Service Worker Initialized.");

let localCache = {
  apiKeys: [],
  globalConfig: null,
  isLoaded: false
};

async function initializeSystemConfig(forceRefresh = false) {
  if (localCache.isLoaded && !forceRefresh) return localCache;

  return new Promise((resolve) => {
    chrome.storage.local.get(["cachedApiKeys", "globalConfig"], async (result) => {
      if (result.cachedApiKeys && result.globalConfig && !forceRefresh) {
        localCache.apiKeys = result.cachedApiKeys;
        localCache.globalConfig = result.globalConfig;
        localCache.isLoaded = true;
        Logger.info("System", "Config successfully loaded from local cache.");
        resolve(localCache);
      } else {
        Logger.info("System", "Local cache stale/empty. Fetching from Firestore...");
        try {
          const [apiKeys, globalConfig] = await Promise.all([
            getApiKeys(INJECTED_UID),
            getGlobalConfig()
          ]);
          
          localCache.apiKeys = apiKeys || [];
          localCache.globalConfig = globalConfig || null;
          localCache.isLoaded = true;

          chrome.storage.local.set({
            cachedApiKeys: localCache.apiKeys,
            globalConfig: localCache.globalConfig
          }, () => {
            Logger.info("System", "Local cache populated and written to disk.");
            resolve(localCache);
          });
        } catch (e) {
          Logger.error("System", "Failed to fetch config:", e);
          resolve(null);
        }
      }
    });
  });
}

chrome.runtime.onInstalled.addListener(() => initializeSystemConfig(true));
chrome.runtime.onStartup.addListener(() => initializeSystemConfig(false));

async function setupOffscreenDocument() {
  const path = 'offscreen.html';
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(path)]
  });

  if (existingContexts.length > 0) return;

  await chrome.offscreen.createDocument({
    url: path,
    reasons: ['DOM_PARSER', 'WORKERS'],
    justification: 'OCR Extraction using Tesseract.js'
  });
}

// Initialize offscreen document when SW boots
setupOffscreenDocument()
  .then(() => {
    // Send a ping to pre-warm the OCR worker instantly
    chrome.runtime.sendMessage({ action: 'ping_ocr' }).catch(() => {});
  })
  .catch(e => Logger.warn("System", "Failed to setup offscreen doc:", e.message));

async function handleCommand(command, tab) {
  const contentScriptReady = await Messenger.ensureContentScript(tab.id);
  if (!contentScriptReady) return;

  if (command === "execute-ping") {
    Logger.info("Command", "execute-ping triggered by user.");

    if (INJECTED_UID.includes("%%")) {
      Logger.warn("Command", "Unlicensed UID detected. Aborting.");
      await Messenger.showMessage(tab.id, "UNLICENSED EXTENSION", true);
      return;
    }

    await Messenger.showLoader(tab.id);

    try {
      // 1. Fetch keys from Memory Cache
      Logger.debug("Pipeline", "Ensuring configuration is cached...");
      const config = await initializeSystemConfig();
      
      if (!config || !config.apiKeys || config.apiKeys.length === 0) {
        Logger.error("Pipeline", "Aborted: Local configuration cache is empty or missing API keys.");
        throw new Error("No API keys found. Please configure keys in dashboard.");
      }
      
      const apiKeys = config.apiKeys;
      // 2. Capture Screenshot
      Logger.debug("Pipeline", "Capturing screenshot...");
      const screenshot = await captureScreen();

      // 3. Query Universal API via Orchestrator with Exponential Backoff
      Logger.debug("Pipeline", "Initiating API Orchestrator...");
      const result = await withRetry(async (attempt) => {
        const currentKey = apiKeys[attempt % apiKeys.length];
        Logger.info("Pipeline", `Attempt ${attempt + 1}: Using API Key ending in ...${currentKey.slice(-4)}`);
        return await runConsensusPipeline(screenshot, currentKey, attempt); // Note: screenshot is now actually OCR text
      }, apiKeys.length); // Strictly bound retries to the exact number of available keys

      // 4. Return answer to UI
      Logger.info("Pipeline", "Execution complete. Sending answer to UI.");
      
      // Phase 6: Cache answer for Alt+D
      await chrome.storage.local.set({ cachedAnswer: result });
      
      await Messenger.hideLoader(tab.id);
      await Messenger.showAnswer(tab.id, result);

    } catch (fatalError) {
      Logger.error("Fatal", "Pipeline crashed:", fatalError.message, fatalError.details || "");
      
      let errorMsg = "ERR 500";
      if (fatalError.type === "AUTH_ERROR") errorMsg = "ERR 403";
      else if (fatalError.type === "RATE_LIMIT") {
        let waitTime = "X";
        if (fatalError.retryAfter) {
          const parsedSecs = parseInt(fatalError.retryAfter, 10);
          if (!isNaN(parsedSecs)) {
            waitTime = parsedSecs;
          } else {
            const dateMs = new Date(fatalError.retryAfter).getTime();
            if (!isNaN(dateMs)) waitTime = Math.max(1, Math.ceil((dateMs - Date.now()) / 1000));
          }
        }
        errorMsg = `Wait ${waitTime}s!!`;
      }
      else if (fatalError.type === "TIMEOUT") errorMsg = "ERR TIMEOUT";
      else if (fatalError.type === "NETWORK_ERROR") errorMsg = "ERR NET";
      
      await Messenger.hideLoader(tab.id);
      await Messenger.showError(tab.id, errorMsg);
    }
    
  } else if (command === "calibrate-area") {
    Logger.info("Command", "calibrate-area triggered.");
    await Messenger.safeSend(tab.id, { type: "START_CALIBRATION" });
    
    if (!INJECTED_UID.includes("%%")) {
      try {
        let storage = await chrome.storage.local.get("cachedApiKeys");
        if (storage.cachedApiKeys && storage.cachedApiKeys.length > 0) {
          cachedApiKeys = storage.cachedApiKeys;
        } else {
          Logger.debug("Pipeline", "Pre-fetching API keys in background...");
          cachedApiKeys = await getApiKeys(INJECTED_UID);
          await chrome.storage.local.set({ cachedApiKeys: cachedApiKeys });
          Logger.info("Pipeline", "API keys cached successfully.");
        }
      } catch (e) {
        Logger.error("Pipeline", "Failed to cache API keys:", e.message);
      }
    }
  } else if (command === "drag-crop") {
    Logger.info("Command", "drag-crop triggered.");
    await Messenger.safeSend(tab.id, { type: "START_DRAG_CROP" });
    
    if (!INJECTED_UID.includes("%%")) {
      try {
        let storage = await chrome.storage.local.get("cachedApiKeys");
        if (storage.cachedApiKeys && storage.cachedApiKeys.length > 0) {
          cachedApiKeys = storage.cachedApiKeys;
        } else {
          cachedApiKeys = await getApiKeys(INJECTED_UID);
          await chrome.storage.local.set({ cachedApiKeys: cachedApiKeys });
        }
      } catch (e) {}
    }
  }
}

chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || tab.url.startsWith("chrome://")) return;
  await handleCommand(command, tab);
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_AUTH_STATUS") {
    sendResponse({ 
      isAuthed: !INJECTED_UID.includes("%%"), 
      uid: INJECTED_UID.includes("%%") ? null : INJECTED_UID 
    });
    return true;
  }
  
  if (request.type === "TRIGGER_COMMAND") {
    handleCommand(request.command, sender.tab);
    return true;
  }

  if (request.type === "SYNC_CONFIG") {
    getGlobalConfig().then(config => {
      if (config && (config.primaryModel || config.secondaryModel || config.tiebreakerModel)) {
        chrome.storage.local.set({ globalConfig: config });
        Logger.info("System", `Global config synced. Primary: ${config.primaryModel}`);
      }
    });
    return true;
  }
});
