import { Logger } from '../utils/logger.js';
import { queryTextAPI } from './universal.js';

import { CONFIG } from '../config/constants.js';

/**
 * Orchestrates the "Thinker-Extractor" Pipeline
 */
export async function runConsensusPipeline(payload, activeKey, attemptIndex = 0) {
    if (payload.type !== 'text') {
        throw new Error("Orchestrator requires text payload (OCR output).");
    }

    // Dynamically fetch models and parameters from synced global config
    const { globalConfig } = await chrome.storage.local.get("globalConfig");
    const primaryModelConfig = globalConfig?.primaryModel || ["qwen/qwen3.6-27b"];
    const modelArray = Array.isArray(primaryModelConfig) ? primaryModelConfig : [primaryModelConfig];
    const THINKER_MODEL = modelArray[attemptIndex % modelArray.length];
    
    const EXTRACTOR_MODEL = globalConfig?.secondaryModel || "llama-3.3-70b-versatile";
    
    const thinkerTokens = globalConfig?.thinkerMaxTokens !== undefined ? globalConfig.thinkerMaxTokens : 5000;
    const extractorTokens = globalConfig?.extractorMaxTokens !== undefined ? globalConfig.extractorMaxTokens : 100;
    const temperature = globalConfig?.temperature !== undefined ? globalConfig.temperature : 0;
    
    const thinkerPrompt = globalConfig?.thinkerPrompt || CONFIG.SYSTEM_PROMPT;
    const extractorPrompt = globalConfig?.extractorPrompt || CONFIG.EXTRACTOR_PROMPT;
    const apiEndpoint = globalConfig?.apiEndpoint || CONFIG.API_ENDPOINT;

    Logger.info("Orchestrator", `Phase 1: Executing Thinker Model (${THINKER_MODEL}) with ${thinkerTokens} tokens`);
    
    let rawOutput = "";
    try {
        rawOutput = await queryTextAPI(payload, activeKey, THINKER_MODEL, false, thinkerPrompt, thinkerTokens, temperature, apiEndpoint);
        if (!rawOutput) throw new Error("Model returned empty response.");
        Logger.debug("ModelOutput", `\n\n=== RAW OUTPUT ===\n${rawOutput.correct || JSON.stringify(rawOutput)}\n==========================\n`);
        
        if (rawOutput && rawOutput.correct) {
            Logger.info("Orchestrator", `Successfully extracted option: ${rawOutput.correct}`);
            return rawOutput; // Must return the parsed object
        } else {
            throw new Error("Model failed to output a strictly formatted answer.");
        }
    } catch (e) {
        Logger.warn("Orchestrator", `Model failed: ${e.message}`);
        throw e; // Pass to retry/fallback logic
    }
}
