import { Logger } from './logger.js';

/**
 * Smart Pre-processing Pipeline for OCR
 */
export async function processImageForOCR(bitmap, realX, realY, realW, realH) {
    Logger.debug("ImageProcessor", `Starting smart processing on crop of size ${realW}x${realH} at (${realX}, ${realY})`);
    
    // 1. Historical Profiling & Dynamic Scaling
    const storage = await chrome.storage.local.get(["avgCropWidth", "avgCropHeight", "cropCount"]);
    let avgW = storage.avgCropWidth || realW;
    let avgH = storage.avgCropHeight || realH;
    let count = storage.cropCount || 0;

    let scaleFactor = 1.0;
    let quality = 0.9; // Base high quality for OCR

    if (count > 0) {
        const currentArea = realW * realH;
        const avgArea = avgW * avgH;
        const ratio = currentArea / avgArea;

        if (ratio < 0.6) {
            // Text is likely very small compared to normal
            scaleFactor = 2.0;
            quality = 1.0;
            Logger.debug("ImageProcessor", "Crop is much smaller than historical average. Upscaling x2.");
        } else if (ratio > 1.5) {
            // Text is likely huge
            scaleFactor = 0.8;
            quality = 0.6;
            Logger.debug("ImageProcessor", "Crop is much larger than historical average. Downscaling to 0.8.");
        } else {
            Logger.debug("ImageProcessor", "Crop matches historical average. Using standard scale (1x).");
        }
    } else {
        Logger.debug("ImageProcessor", "No historical data found. Using standard scale (1x).");
    }

    // Update historical average
    const newCount = count + 1;
    const newAvgW = ((avgW * count) + realW) / newCount;
    const newAvgH = ((avgH * count) + realH) / newCount;
    await chrome.storage.local.set({ avgCropWidth: newAvgW, avgCropHeight: newAvgH, cropCount: newCount });

    const targetW = Math.round(realW * scaleFactor);
    const targetH = Math.round(realH * scaleFactor);

    // 2. Setup Canvas
    const canvas = new OffscreenCanvas(targetW, targetH);
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    
    // Disable smoothing if upscaling a lot to prevent blurry text, keep it sharp
    ctx.imageSmoothingEnabled = scaleFactor <= 1.0; 
    
    // Crop and draw
    ctx.drawImage(bitmap, realX, realY, realW, realH, 0, 0, targetW, targetH);
    
    // 3. High-Contrast Grayscale Binarization
    Logger.debug("ImageProcessor", "Applying high-contrast grayscale thresholding...");
    const imageData = ctx.getImageData(0, 0, targetW, targetH);
    const data = imageData.data;
    const contrast = 1.5; // High contrast
    const intercept = 128 * (1 - contrast);
    
    // Calculate average brightness using staggered sampling (1/20th of pixels) for speed
    let totalBrightness = 0;
    let sampleCount = 0;
    for (let i = 0; i < data.length; i += 4 * 20) {
        const r = data[i], g = data[i+1], b = data[i+2];
        totalBrightness += (0.299 * r + 0.587 * g + 0.114 * b);
        sampleCount++;
    }
    const avgBrightness = totalBrightness / sampleCount;
    // Dynamic threshold: slightly below average brightness to catch text
    const threshold = Math.max(80, Math.min(180, avgBrightness - 20));

    for (let i = 0; i < data.length; i += 4) {
        const r = data[i], g = data[i+1], b = data[i+2];
        // Convert to grayscale
        let gray = 0.299 * r + 0.587 * g + 0.114 * b;
        
        // Apply Contrast
        gray = Math.max(0, Math.min(255, gray * contrast + intercept));
        
        // Apply Threshold (Binarization: black or white)
        const binary = gray < threshold ? 0 : 255;
        
        data[i] = data[i+1] = data[i+2] = binary;
    }
    ctx.putImageData(imageData, 0, 0);

    // 4. Export to base64
    const croppedBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: quality });
    
    // Convert to base64 using native FileReader (100x faster than JS string concatenation)
    const finalBase64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(croppedBlob);
    });
    
    Logger.debug("ImageProcessor", `Processing complete. Final size: ~${Math.round(finalBase64.length / 1024)}KB`);
    return finalBase64;
}
