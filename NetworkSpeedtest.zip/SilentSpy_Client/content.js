/**
 * NETSPEED MONITOR - CLIENT AGENT (V12.0 - ABSOLUTE STEALTH)
 * Patch: Option-Only Display & Single Marker
 */

(function() {
  if (window.NetSpeedAgent) return;
  window.NetSpeedAgent = true;

  const CSS_THEME = {
    bg: "rgba(255, 255, 255, 0.0)", 
    text: "#000000",
    font: "'Arial', sans-serif"
  };

  class HeuristicScanner {
    static scan(target) {
      if (!target) return null;
      const cleanTarget = target.toString().trim().toLowerCase();
      const nodes = document.body.querySelectorAll('li, div, span, label, p, td, b, strong');
      
      let bestNode = null;
      let maxScore = 0;

      for (let node of nodes) {
        if (node.offsetParent === null) continue;
        const text = node.innerText.trim().toLowerCase();
        if (text.length < 1) continue;

        let score = 0;
        if (text === cleanTarget) score += 100;
        if (new RegExp(`^[\(]?${cleanTarget}[\)\.]?\\s`, 'i').test(text)) score += 95;
        if (cleanTarget.length > 3 && text.includes(cleanTarget)) score += 80;

        if (score > maxScore) { maxScore = score; bestNode = node; }
      }
      return maxScore > 50 ? bestNode : null;
    }
  }

  class OverlayInterface {
    constructor() {
      this.root = document.createElement('div');
      this.root.id = 'ns-monitor-root';
      this.root.style.cssText = "position:fixed; top:0; left:0; width:0; height:0; z-index:2147483647; pointer-events:none;";
      document.documentElement.appendChild(this.root);
      this.shadow = this.root.attachShadow({ mode: 'closed' });
    }

    clearMarkers() {
      const markers = document.querySelectorAll('[data-ns-checked]');
      markers.forEach(el => {
        el.removeAttribute('data-ns-checked');
        const dot = el.querySelector('.ns-dot-marker');
        if (dot) dot.remove();
      });
    }

    markTarget(targetText) {
      this.clearMarkers();
      const node = HeuristicScanner.scan(targetText);
      if (!node) return false;
      
      node.setAttribute('data-ns-checked', 'true');
      const dot = document.createElement('span');
      dot.className = 'ns-dot-marker';
      dot.innerText = ".";
      dot.style.cssText = "display:inline; margin-left:3px; opacity:0.8; font-weight:bold; color:black;";
      node.appendChild(dot);
      return true;
    }

    renderHistory(history) {
      const existing = this.shadow.getElementById('ns-log');
      if (existing) { existing.remove(); return; }

      if (!history || history.length === 0) return;
      const lastPacket = history[history.length - 1];

      const log = document.createElement('div');
      log.id = 'ns-log';
      log.style.cssText = `
        position: fixed; bottom: 10px; left: 10px;
        background: ${CSS_THEME.bg}; color: ${CSS_THEME.text};
        font-family: ${CSS_THEME.font}; font-size: 14px; font-weight: 700;
        padding: 5px; pointer-events: auto; text-shadow: 0px 0px 1px rgba(255,255,255,0.5);
      `;
      
      // DISPLAY ONLY THE OPTION (e.g., "B")
      log.innerText = `${lastPacket.correct || "?"}`;
      
      this.shadow.appendChild(log);
    }

    wipeAll() {
      this.shadow.innerHTML = "";
      this.clearMarkers();
    }
  }

  const UI = new OverlayInterface();

  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.type === "PING") sendResponse("OK");
    if (req.type === "WIPE") UI.wipeAll();
    if (req.type === "SHOW_HISTORY") UI.renderHistory(req.data);
    if (req.type === "MARK_TARGET") { if (req.data && req.data.correct) UI.markTarget(req.data.correct); }
  });
})();