/**
 * NETSPEED MONITOR - BACKGROUND SERVICE (V11.0 - HYDRA)
 * Architecture: Fault-Tolerant Load Balancing
 */

const CONFIG = {
  // THE HYDRA POOL: 4 Active Nodes
  API_POOL: ["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",
    "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",
    "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",
    "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"
  ],
  ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  MODEL: "meta-llama/llama-4-scout-17b-16e-instruct",
  
  SYSTEM_PROMPT: `
    ROLE: Expert Solver.
    TASK: Identify Correct Option.
    OUTPUT: JSON ONLY.
    FORMAT: 
    [Reasoning...]
    {"q_num": <Integer|null>, "correct": "<Option Letter>", "summary": ""}
  `
};

/**
 * CLASS: Round-Robin Load Balancer
 * Mimics enterprise traffic routing.
 */
class LoadBalancer {
  constructor(keys) {
    this.keys = keys;
    this.index = 0;
    this.totalKeys = keys.length;
  }

  getKey() {
    return this.keys[this.index];
  }

  rotate() {
    const prev = this.index;
    this.index = (this.index + 1) % this.totalKeys;
    console.warn(`[Hydra] Node ${prev} Unstable. Rerouting to Node ${this.index}...`);
  }

  // Smart selection based on hashing (optional future expansion)
  getHashKey(input) {
    let hash = 0;
    for (let i = 0; i < input.length; i++) hash = (hash + input.charCodeAt(i)) % this.totalKeys;
    return this.keys[hash];
  }
}

class SessionManager {
  static async logPacket(data) {
    const storage = await chrome.storage.local.get("net_logs");
    let logs = storage.net_logs || [];
    const nextSeq = logs.length > 0 ? (logs[logs.length - 1].q_num || 0) + 1 : 1;
    
    // Logic: Update if Q# exists (re-scan), else Append
    const existingIndex = logs.findIndex(l => l.q_num === data.q_num);
    const packet = { q_num: data.q_num || nextSeq, correct: data.correct };

    if (existingIndex !== -1 && data.q_num) logs[existingIndex] = packet;
    else logs.push(packet);

    logs.sort((a, b) => a.q_num - b.q_num);
    await chrome.storage.local.set({ net_logs: logs });
    return logs;
  }

  static async getLogs() {
    const s = await chrome.storage.local.get("net_logs");
    return s.net_logs || [];
  }
  static async purge() { await chrome.storage.local.remove("net_logs"); }
}

// --- UTILS ---
function extractJSON(str) {
  try {
    const s = str.indexOf('{'), e = str.lastIndexOf('}');
    if (s !== -1 && e !== -1) return JSON.parse(str.substring(s, e + 1));
  } catch (e) {}
  const m = str.match(/"correct":\s*"([^"]+)"/);
  return m ? { correct: m[1] } : { correct: null };
}

// --- CORE ENGINE ---
const Hydra = new LoadBalancer(CONFIG.API_POOL);

async function analyzeSignal(img) {
  // FAILOVER LOOP: Tries up to 3 different keys if one fails
  for (let i = 0; i < 3; i++) {
    try {
      const res = await fetch(CONFIG.ENDPOINT, {
        method: "POST",
        headers: { 
          "Authorization": `Bearer ${Hydra.getKey()}`, 
          "Content-Type": "application/json" 
        },
        body: JSON.stringify({
          model: CONFIG.MODEL,
          messages: [{ role: "user", content: [{ type: "text", text: CONFIG.SYSTEM_PROMPT }, { type: "image_url", image_url: { url: img } }] }],
          temperature: 0.1, max_tokens: 300
        })
      });

      // REROUTING LOGIC
      if (!res.ok) {
        console.error(`[Hydra] Node Error: ${res.status}`);
        Hydra.rotate(); // Switch key immediately
        continue;       // Retry loop with new key
      }

      const d = await res.json();
      return extractJSON(d.choices[0].message.content);

    } catch (e) {
      console.error("[Hydra] Network Partition:", e);
      Hydra.rotate(); // Switch key on network error
    }
  }
  return { correct: null };
}

// --- EVENT BUS ---
chrome.commands.onCommand.addListener(async (cmd) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  // Auto-Inject (Self Healing)
  try { await chrome.tabs.sendMessage(tab.id, { type: "PING" }); } 
  catch (e) { try { await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }); await new Promise(r => setTimeout(r, 50)); } catch (e) { return; } }

  if (cmd === "reset-cache") {
    await SessionManager.purge();
    chrome.tabs.sendMessage(tab.id, { type: "WIPE" });
  }
  if (cmd === "show-logs") { // Alt+A
    const h = await SessionManager.getLogs();
    chrome.tabs.sendMessage(tab.id, { type: "SHOW_HISTORY", data: h });
  }
  if (cmd === "execute-ping") { // Alt+X
    const res = await analyzeSignal(await chrome.tabs.captureVisibleTab());
    await SessionManager.logPacket(res);
    if (res.correct) chrome.tabs.sendMessage(tab.id, { type: "MARK_TARGET", data: res });
  }
});