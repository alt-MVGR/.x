document.getElementById('testBtn').addEventListener('click', runTest);

// Auto-run on open
runTest();

function runTest() {
  const pingEl = document.getElementById('ping');
  const jitterEl = document.getElementById('jitter');
  const graph = document.getElementById('graph');
  
  pingEl.innerText = "Testing...";
  graph.innerHTML = "";

  let pings = [];
  
  // Create fake graph bars
  for(let i=0; i<50; i++) {
    let h = Math.floor(Math.random() * 40) + 10;
    let bar = document.createElement('div');
    bar.className = 'bar';
    bar.style.height = h + 'px';
    bar.style.left = (i * 6) + 'px';
    graph.appendChild(bar);
  }

  setTimeout(() => {
    let ping = Math.floor(Math.random() * 15) + 20; // 20-35ms
    let jitter = Math.floor(Math.random() * 5);
    pingEl.innerText = ping + " ms";
    jitterEl.innerText = jitter + " ms";
  }, 1500);
}