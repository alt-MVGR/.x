import { ParserError } from './errors.js';
import { Logger } from './logger.js';

/**
 * Robust text parser that completely ignores JSON.
 * Aggressively extracts A, B, C, D, 1, 2, 3, 4 from model output.
 */
export function extractOption(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    throw new ParserError("Output is not a valid string", { rawText });
  }

  Logger.debug("Parser", "Raw input:", rawText);

  // 1. Strip <think> blocks completely
  let text = rawText.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();

  // If the entire text was a think block (model cut off before closing tag)
  // or if the tag was malformed, let's aggressively remove anything between <think> and end of string if no closing tag
  text = text.replace(/<think>[\s\S]*$/gi, '').trim();

  // If there's nothing left, we can't parse it
  if (!text) {
    throw new ParserError("Output was empty after stripping reasoning blocks.", { rawText });
  }

  Logger.debug("Parser", "Stripped text:", text);

  // 2. Look for standalone options A, B, C, D or 1, 2, 3, 4
  // We prefer exact matches first
  const exactMatch = text.match(/^[A-D1-4]$/i);
  if (exactMatch) {
    return normalizeOption(exactMatch[0]);
  }

  // 3. Look for common formats like "Option C", "**B**", "C)", "Answer: A"
  const formattedMatch = text.match(/(?:option|answer:?|correct:?)\s*[*_]*([A-D1-4])[*_]*/i);
  if (formattedMatch) {
    return normalizeOption(formattedMatch[1]);
  }

  // 4. Fallback: Find the FIRST valid character (A, B, C, D, 1, 2, 3, 4) in the remaining text
  // This is aggressive but necessary for models that ignore instructions.
  const aggressiveMatch = text.match(/\b([A-D1-4])\b/i);
  if (aggressiveMatch) {
    return normalizeOption(aggressiveMatch[1]);
  }

  throw new ParserError("Could not find a valid option (A-D, 1-4) in the response.", { strippedText: text });
}

function normalizeOption(char) {
  const upper = char.toUpperCase();
  // Map numbers to letters for UI consistency if needed
  const map = { '1': 'A', '2': 'B', '3': 'C', '4': 'D' };
  return { correct: map[upper] || upper };
}
