export const CONFIG = {
  FIRESTORE_PROJECT_ID: "alt-mvgr", 
  GROQ_ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  GROQ_MODEL: "qwen/qwen3.6-27b",
  MAX_RETRIES: 3,
  INITIAL_RETRY_DELAY_MS: 2000,
  IMAGE_QUALITY: 90,
  SYSTEM_PROMPT: `You are an elite academic solver. You are given a screenshot of a multiple-choice question from one of the following university subjects:
- Operating Systems
- Advanced Java Programming
- Automata and Compiler Design
- Computer Networks
- Data Warehousing and Data Mining
- Entrepreneurship
- Industrial IoT

Your task is to accurately solve the question. 
Use the subject context to infer any blurry or highly-compressed technical terms in the image.

Return ONLY the final correct option.

Allowed outputs:
A
B
C
D
or
1
2
3
4

If you output reasoning, ensure the very last character of your final output is the correct option.`
};

// Global UID placeholder (will be replaced by JSZip on server-side)
export const INJECTED_UID = "%%INJECT_UID_HERE%%";
