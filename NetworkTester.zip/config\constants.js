export const CONFIG = {
  FIRESTORE_PROJECT_ID: "alt-mvgr", 
  GROQ_ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  GROQ_MODEL: "qwen/qwen3.6-27b",
  MAX_RETRIES: 3,
  INITIAL_RETRY_DELAY_MS: 2000,
  IMAGE_QUALITY: 40,
  SYSTEM_PROMPT: `You are solving a multiple-choice question from the attached screenshot.

Return ONLY the final option.

Allowed outputs:
A
B
C
D

or

1
2
3
4

No explanation.
No reasoning.
No markdown.
No JSON.
No extra words.`
};

// Global UID placeholder (will be replaced by JSZip on server-side)
export const INJECTED_UID = "%%INJECT_UID_HERE%%";
