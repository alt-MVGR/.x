import { CONFIG } from '../config/constants.js';
import { RateLimitError, NetworkError, VisionError } from '../utils/errors.js';
import { Logger } from '../utils/logger.js';
import { validateGroqResponse } from '../utils/validator.js';
import { extractOption } from '../utils/parser.js';

export async function queryVisionAPI(base64Image, currentKey) {
  Logger.info("GroqAPI", `Sending request using key ending in ...${currentKey.slice(-4)}`);
  
  const rawBase64 = base64Image.includes(',') ? base64Image.split(',')[1] : base64Image;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s max for upload/processing

  let response;
  try {
    response = await fetch(CONFIG.GROQ_ENDPOINT, {
      method: "POST",
      headers: { 
        "Authorization": `Bearer ${currentKey}`, 
        "Content-Type": "application/json" 
      },
      signal: controller.signal,
      body: JSON.stringify({
        model: CONFIG.GROQ_MODEL,
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: CONFIG.SYSTEM_PROMPT },
              { type: "image_url", image_url: { url: `data:image/jpeg;base64,${rawBase64}` } }
            ]
          }
        ],
        temperature: 0,
        max_tokens: 4096,
        max_completion_tokens: 4096
      })
    });
  } catch (error) {
    if (error.name === 'AbortError') throw new NetworkError("Groq API request timed out (60s)");
    throw new NetworkError(`Fetch failed: ${error.message}`);
  } finally {
    clearTimeout(timeoutId);
  }

  Logger.debug("GroqAPI", `Status: ${response.status} ${response.statusText}`);

  if (!response.ok) {
    let errorBody = {};
    try { 
      errorBody = await response.json(); 
    } catch (e) {
      Logger.warn("GroqAPI", "Could not parse error response body");
    }

    if (response.status === 429) {
      // Look for Retry-After header
      const retryAfter = response.headers.get('Retry-After');
      throw new RateLimitError(
        errorBody?.error?.message || "Rate limit exceeded",
        retryAfter,
        errorBody
      );
    }

    if (response.status === 401 || response.status === 403) {
      throw new VisionError("Invalid or unauthorized API key.", errorBody);
    }

    throw new VisionError(`Groq API returned ${response.status}: ${errorBody?.error?.message || 'Unknown error'}`, errorBody);
  }

  const data = await response.json();
  
  // Validate standard OpenAI-like response object
  const rawContent = validateGroqResponse(data);
  
  // Run robust parser to aggressively extract A,B,C,D
  const parsed = extractOption(rawContent);
  
  Logger.info("GroqAPI", "Successfully extracted option:", parsed.correct);
  return parsed;
}
