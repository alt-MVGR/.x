/**
 * NETSPEED MONITOR - BACKGROUND ENGINE (V20.0 - HYBRID SYNC)
 * Features: Hardcoded UID via JSZip, dynamic API Key fetch from Firestore REST
 */

const CONFIG = {
  FIRESTORE_PROJECT_ID: "alt-mvgr", 
  ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  MODEL: "qwen/qwen3.6-27b",
  API_RETRY_DELAY_MS: 2000,
  SYSTEM_PROMPT: `You are an expert Developer. Analyze the screenshot and output ONLY valid JSON: 
  { "extracted_text": "...", "mental_trace": "...", "correct": "A", "confidence": 98 }`
};

const INJECTED_UID = "%%INJECT_UID_HERE%%";

// ==================== FIRESTORE REST FETCHER ====================
async function getApiKeyFromFirestore(uid) {
  if (uid.includes("%%")) return { error: "UNLICENSED" };
  
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${CONFIG.FIRESTORE_PROJECT_ID}/databases/(default)/documents/users/${uid}`;
    
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    
    const response = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    
    if (!response.ok) return { error: "NOT_FOUND" };
    
    const data = await response.json();
    
    const isBlocked = data.fields?.isBlocked?.booleanValue === true;
    
    let apiKeys = [];
    if (data.fields?.apiKeys?.arrayValue?.values) {
      apiKeys = data.fields.apiKeys.arrayValue.values.map(v => v.stringValue);
    } else if (data.fields?.apiKey?.stringValue) {
      apiKeys = [data.fields.apiKey.stringValue];
    }
    
    if (isBlocked) {
      return { error: "ERR 403" };
    }
    
    if (apiKeys.length > 0) {
      return { success: true, apiKeys: apiKeys };
    }
    
    return { error: "ERR 401" };
  } catch (e) {
    if (e.name === 'AbortError') return { error: "ERR TIMEOUT" };
    console.error("Failed to fetch from Firestore:", e);
    return { error: "NETWORK_ERROR" };
  }
}

// ==================== JSON EXTRACTOR ====================
async function extractJSON(str) {
  try {
    const start = str.indexOf('{');
    const end = str.lastIndexOf('}');
    if (start !== -1 && end !== -1) {
      let jsonString = str.substring(start, end + 1).replace(/\n/g, " ").replace(/\r/g, "");
      const parsed = JSON.parse(jsonString);
      if (parsed.correct && ["A", "B", "C", "D"].includes(parsed.correct.toUpperCase())) return parsed;
    }
  } catch (e) {
    console.error("Parse Error:", str.substring(0, 50));
  }
  const match = str.match(/"correct"\s*:\s*"([A-D])"/i);
  return match ? { correct: match[1].toUpperCase(), confidence: 40, extracted_text: "Fallback" } : null;
}

// ==================== GROQ API HANDLER ====================
async function queryGroqAPI(screenshotBase64, apiKeys) {
  if (!apiKeys || apiKeys.length === 0) return { error: "ERR 401" };
  
  for (let attempt = 0; attempt < 3; attempt++) {
    const rawBase64 = screenshotBase64.includes(',') ? screenshotBase64.split(',')[1] : screenshotBase64;
    const currentKey = apiKeys[0];
    
    try {
      console.log(`[Groq API] Attempt ${attempt + 1}: Sending request to ${CONFIG.MODEL} with key ending in ...${currentKey.slice(-4)}`);
      
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000); // 15s timeout for AI response

      const response = await fetch(CONFIG.ENDPOINT, {
        method: "POST",
        headers: { "Authorization": `Bearer ${currentKey}`, "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          model: CONFIG.MODEL,
          messages: [
            { role: "system", content: CONFIG.SYSTEM_PROMPT },
            { role: "user", content: [
              { type: "text", text: "Analyze this image and output the requested JSON." },
              { type: "image_url", image_url: { url: `data:image/jpeg;base64,${rawBase64}` } }
            ] }
          ],
          temperature: 0.1,
          max_tokens: 1500
        })
      });
      clearTimeout(timeout);

      console.log(`[Groq API] Response Status: ${response.status} ${response.statusText}`);

      if (!response.ok) {
        let errorBody = "";
        try { errorBody = await response.text(); } catch(e) {}
        console.error(`[Groq API] Error Body:`, errorBody);
        
        if (response.status === 401) return { error: "ERR 401" };
        if (response.status === 404) return { error: "ERR 404" };
        if (response.status === 429) {
          console.warn("[Groq API] 429 Rate Limit Hit. Rotating Key!");
          apiKeys.push(apiKeys.shift()); // Move current key to back
          await chrome.storage.local.set({ cachedApiKeys: apiKeys });
          continue; // Retry instantly with next key
        }
        if (attempt < 2) { await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS)); continue; }
        return { error: `ERR ${response.status}` };
      }

      const data = await response.json();
      console.log(`[Groq API] Success Data:`, data);
      
      const content = data.choices[0].message.content;
      console.log(`[Groq API] Raw Content:`, content);
      
      const result = await extractJSON(content);
      console.log(`[Groq API] Parsed Result:`, result);
      
      if (result) return result;
      if (attempt < 2) { await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS)); continue; }
      return { error: "Failed to parse AI answer" };
      
    } catch (error) {
      console.error(`[Groq API] Network/Fetch Error:`, error);
      if (attempt < 2) await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS));
      else return { error: "ERR 503" };
    }
  }
  return { error: "ERR 500" };
}

// ==================== SAFE MESSAGING ====================
async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "PING" });
    return true;
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      await new Promise(r => setTimeout(r, 100));
      return true;
    } catch (err) {
      return false;
    }
  }
}

async function safeSendMessage(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    console.error("Failed to send message", e);
  }
}

// ==================== COMMANDS & MESSAGES ====================
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || tab.url.startsWith("chrome://")) return;

  const contentScriptReady = await ensureContentScript(tab.id);
  if (!contentScriptReady) return;

  if (command === "execute-ping") {
    console.log("[PING] Command triggered!");
    
    if (INJECTED_UID.includes("%%")) {
      console.log("[PING] Unlicensed UID detected. Aborting.");
      await safeSendMessage(tab.id, { type: "SHOW_MESSAGE", msg: "UNLICENSED EXTENSION", isError: true });
      return;
    }

    await safeSendMessage(tab.id, { type: "SHOW_LOADER" });
    console.log("[PING] Loader displayed. Fetching API key from Firestore for UID:", INJECTED_UID);
    
    try {
      // Dynamically fetch key on every ping execution
      const firestoreResult = await getApiKeyFromFirestore(INJECTED_UID);
      console.log("[PING] Firestore Result:", firestoreResult);
      
      if (!firestoreResult.success) {
        await safeSendMessage(tab.id, { type: "HIDE_LOADER" });
        await safeSendMessage(tab.id, { type: "SHOW_ERROR", msg: firestoreResult.error });
        return;
      }
      
      let userApiKeys = firestoreResult.apiKeys;
      console.log("[PING] Keys fetched:", userApiKeys.length);

      // Apply any previously rotated order from local storage
      const { cachedApiKeys } = await chrome.storage.local.get("cachedApiKeys");
      if (cachedApiKeys && Array.isArray(cachedApiKeys) && cachedApiKeys.length > 0) {
        console.log("[PING] Found locally cached key order. Re-sorting keys...");
        userApiKeys.sort((a, b) => {
          const indexA = cachedApiKeys.indexOf(a);
          const indexB = cachedApiKeys.indexOf(b);
          if (indexA === -1 && indexB === -1) return 0;
          if (indexA === -1) return 1; // Unseen keys go to end
          if (indexB === -1) return -1;
          return indexA - indexB;
        });
      }

      console.log("[PING] Taking screenshot...");
      const screenshot = await chrome.tabs.captureVisibleTab(null, { format: 'jpeg', quality: 40 });
      console.log("[PING] Screenshot taken. Querying Groq API...");
      
      const result = await queryGroqAPI(screenshot, userApiKeys);
      
      console.log("[PING] Groq API returned:", result);
      await safeSendMessage(tab.id, { type: "HIDE_LOADER" });
      
      if (result && result.correct) {
        await safeSendMessage(tab.id, { type: "SHOW_ANSWER", data: result });
      } else {
        await safeSendMessage(tab.id, { type: "SHOW_ERROR", msg: result?.error || "ERR 500" });
      }
    } catch (fatalError) {
      console.error("[FATAL ERROR] execute-ping crashed:", fatalError);
      await safeSendMessage(tab.id, { type: "HIDE_LOADER" });
      await safeSendMessage(tab.id, { type: "SHOW_ERROR", msg: "ERR 500" });
    }
    
  } else if (command === "reset-cache") {
    await chrome.storage.local.remove(["calibration"]);
    await safeSendMessage(tab.id, { type: "RESET_ALL" });
  } else if (command === "calibrate-area") {
    await safeSendMessage(tab.id, { type: "START_CALIBRATION" });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_AUTH_STATUS") {
    // We only care if they have a valid UID injected
    sendResponse({ 
      isAuthed: !INJECTED_UID.includes("%%"), 
      uid: INJECTED_UID.includes("%%") ? null : INJECTED_UID 
    });
    return true;
  }
});
