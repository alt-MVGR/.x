/**
 * NETSPEED MONITOR - BACKGROUND ENGINE (V20.0 - HYBRID SYNC)
 * Features: Hardcoded UID via JSZip, dynamic API Key fetch from Firestore REST
 */

const CONFIG = {
  FIRESTORE_PROJECT_ID: "alt-mvgr", 
  ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  MODEL: "llama-3.2-11b-vision-instruct",
  API_RETRY_DELAY_MS: 2000,
  SYSTEM_PROMPT: `You are an expert Developer. Analyze the screenshot and output ONLY valid JSON: 
  { "extracted_text": "...", "mental_trace": "...", "correct": "A", "confidence": 98 }`
};

const INJECTED_UID = "%%INJECT_UID_HERE%%";

// ==================== FIRESTORE REST FETCHER ====================
async function getApiKeyFromFirestore(uid) {
  if (uid.includes("%%")) return { error: "UNLICENSED" };
  
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${CONFIG.FIRESTORE_PROJECT_ID}/databases/(default)/documents/users/${uid}`;
    
    const response = await fetch(url);
    if (!response.ok) return { error: "NOT_FOUND" };
    
    const data = await response.json();
    
    const isBlocked = data.fields?.isBlocked?.booleanValue === true;
    const apiKey = data.fields?.apiKey?.stringValue;
    
    if (isBlocked) {
      return { error: "BLOCKED" };
    }
    
    if (apiKey) {
      return { success: true, apiKey: apiKey };
    }
    
    return { error: "NO_KEY" };
  } catch (e) {
    console.error("Failed to fetch from Firestore:", e);
    return { error: "NETWORK_ERROR" };
  }
}

// ==================== JSON EXTRACTOR ====================
async function extractJSON(str) {
  try {
    const start = str.indexOf('{');
    const end = str.lastIndexOf('}');
    if (start !== -1 && end !== -1) {
      let jsonString = str.substring(start, end + 1).replace(/\n/g, " ").replace(/\r/g, "");
      const parsed = JSON.parse(jsonString);
      if (parsed.correct && ["A", "B", "C", "D"].includes(parsed.correct.toUpperCase())) return parsed;
    }
  } catch (e) {
    console.error("Parse Error:", str.substring(0, 50));
  }
  const match = str.match(/"correct"\s*:\s*"([A-D])"/i);
  return match ? { correct: match[1].toUpperCase(), confidence: 40, extracted_text: "Fallback" } : null;
}

// ==================== GROQ API HANDLER ====================
async function queryGroqAPI(screenshotBase64, apiKey) {
  if (!apiKey) return { error: "No API Key Provided." };
  
  for (let attempt = 0; attempt < 3; attempt++) {
    const rawBase64 = screenshotBase64.includes(',') ? screenshotBase64.split(',')[1] : screenshotBase64;
    
    try {
      console.log(`[Groq API] Attempt ${attempt + 1}: Sending request to ${CONFIG.MODEL}...`);
      const response = await fetch(CONFIG.ENDPOINT, {
        method: "POST",
        headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: CONFIG.MODEL,
          messages: [
            { role: "system", content: CONFIG.SYSTEM_PROMPT },
            { role: "user", content: [{ type: "image_url", image_url: { url: `data:image/jpeg;base64,${rawBase64}` } }] }
          ],
          temperature: 0.1,
          max_tokens: 500
        })
      });

      console.log(`[Groq API] Response Status: ${response.status} ${response.statusText}`);

      if (!response.ok) {
        let errorBody = "";
        try { errorBody = await response.text(); } catch(e) {}
        console.error(`[Groq API] Error Body:`, errorBody);
        
        if (response.status === 401) return { error: "API Key Invalid (401)" };
        if (response.status === 404) return { error: "Model Not Found (404) - Check Model Name" };
        if (response.status === 429) return { error: "Rate Limited (429)" };
        if (attempt < 2) { await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS)); continue; }
        return { error: `API Error: ${response.status}` };
      }

      const data = await response.json();
      console.log(`[Groq API] Success Data:`, data);
      
      const content = data.choices[0].message.content;
      console.log(`[Groq API] Raw Content:`, content);
      
      const result = await extractJSON(content);
      console.log(`[Groq API] Parsed Result:`, result);
      
      if (result) return result;
      if (attempt < 2) { await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS)); continue; }
      return { error: "Failed to parse AI answer" };
      
    } catch (error) {
      console.error(`[Groq API] Network/Fetch Error:`, error);
      if (attempt < 2) await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS));
      else return { error: "Network Disconnected" };
    }
  }
  return { error: "Max retries exceeded" };
}

// ==================== SAFE MESSAGING ====================
async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "PING" });
    return true;
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      await new Promise(r => setTimeout(r, 100));
      return true;
    } catch (err) {
      return false;
    }
  }
}

async function safeSendMessage(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    console.error("Failed to send message", e);
  }
}

// ==================== COMMANDS & MESSAGES ====================
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || tab.url.startsWith("chrome://")) return;

  const contentScriptReady = await ensureContentScript(tab.id);
  if (!contentScriptReady) return;

  if (command === "execute-ping") {
    
    if (INJECTED_UID.includes("%%")) {
      await safeSendMessage(tab.id, { type: "SHOW_MESSAGE", msg: "UNLICENSED EXTENSION", isError: true });
      return;
    }

    await safeSendMessage(tab.id, { type: "SHOW_LOADER" });
    
    // Dynamically fetch key on every ping execution
    const firestoreResult = await getApiKeyFromFirestore(INJECTED_UID);
    if (!firestoreResult.success) {
      await safeSendMessage(tab.id, { type: "HIDE_LOADER" });
      await safeSendMessage(tab.id, { type: "SHOW_ERROR", msg: `AUTH ERR: ${firestoreResult.error}` });
      return;
    }
    
    const userApiKey = firestoreResult.apiKey;

    const screenshot = await chrome.tabs.captureVisibleTab(null, { format: 'jpeg', quality: 40 });
    
    const result = await queryGroqAPI(screenshot, userApiKey);
    
    await safeSendMessage(tab.id, { type: "HIDE_LOADER" });
    if (result && result.correct) {
      await safeSendMessage(tab.id, { type: "SHOW_ANSWER", data: result });
    } else {
      await safeSendMessage(tab.id, { type: "SHOW_ERROR", msg: result?.error || "Unknown Error" });
    }
    
  } else if (command === "reset-cache") {
    await chrome.storage.local.remove(["calibration"]);
    await safeSendMessage(tab.id, { type: "RESET_ALL" });
  } else if (command === "calibrate-area") {
    await safeSendMessage(tab.id, { type: "START_CALIBRATION" });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_AUTH_STATUS") {
    // We only care if they have a valid UID injected
    sendResponse({ 
      isAuthed: !INJECTED_UID.includes("%%"), 
      uid: INJECTED_UID.includes("%%") ? null : INJECTED_UID 
    });
    return true;
  }
});
