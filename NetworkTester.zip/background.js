/**
 * NETSPEED MONITOR - BACKGROUND ENGINE (V18.0 - FIRESTORE SYNC)
 * Features: Manual UID Auth via Firestore REST, Strict Blocking checks
 */

const CONFIG = {
  FIRESTORE_PROJECT_ID: "alt-mvgr", 
  ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  MODEL: "meta-llama/llama-4-scout-17b-16e-instruct",
  API_RETRY_DELAY_MS: 2000,
  SYSTEM_PROMPT: `You are an expert Developer. Analyze the screenshot and output ONLY valid JSON: 
  { "extracted_text": "...", "mental_trace": "...", "correct": "A", "confidence": 98 }`
};

const INJECTED_UID = "%%INJECT_UID_HERE%%";

// ==================== FIRESTORE REST FETCHER ====================
async function getApiKeyFromFirestore(uid) {
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${CONFIG.FIRESTORE_PROJECT_ID}/databases/(default)/documents/users/${uid}`;
    
    const response = await fetch(url);
    if (!response.ok) return { error: "NOT_FOUND" };
    
    const data = await response.json();
    
    // Firestore REST API wraps data in type objects (e.g., stringValue, booleanValue)
    const isBlocked = data.fields?.isBlocked?.booleanValue === true;
    const apiKey = data.fields?.apiKey?.stringValue;
    
    if (isBlocked) {
      return { error: "BLOCKED" };
    }
    
    if (apiKey) {
      return { success: true, apiKey: apiKey };
    }
    
    return { error: "NO_KEY" };
  } catch (e) {
    console.error("Failed to fetch from Firestore:", e);
    return { error: "NETWORK_ERROR" };
  }
}

// ==================== JSON EXTRACTOR ====================
async function extractJSON(str) {
  try {
    const start = str.indexOf('{');
    const end = str.lastIndexOf('}');
    if (start !== -1 && end !== -1) {
      let jsonString = str.substring(start, end + 1).replace(/\n/g, " ").replace(/\r/g, "");
      const parsed = JSON.parse(jsonString);
      if (parsed.correct && ["A", "B", "C", "D"].includes(parsed.correct.toUpperCase())) return parsed;
    }
  } catch (e) {
    console.error("Parse Error:", str.substring(0, 50));
  }
  const match = str.match(/"correct"\s*:\s*"([A-D])"/i);
  return match ? { correct: match[1].toUpperCase(), confidence: 40, extracted_text: "Fallback" } : null;
}

// ==================== GROQ API HANDLER ====================
async function queryGroqAPI(screenshotBase64, apiKey) {
  if (!apiKey) return null;
  
  for (let attempt = 0; attempt < 3; attempt++) {
    const rawBase64 = screenshotBase64.includes(',') ? screenshotBase64.split(',')[1] : screenshotBase64;
    
    try {
      const response = await fetch(CONFIG.ENDPOINT, {
        method: "POST",
        headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: CONFIG.MODEL,
          messages: [
            { role: "system", content: CONFIG.SYSTEM_PROMPT },
            { role: "user", content: [{ type: "image_url", image_url: { url: `data:image/jpeg;base64,${rawBase64}` } }] }
          ],
          temperature: 0.1,
          max_tokens: 500
        })
      });

      if (!response.ok) {
        if (response.status === 401) return { error: "API Key Invalid (401)" };
        if (response.status === 429) return { error: "Rate Limited (429)" };
        if (attempt < 2) { await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS)); continue; }
        return { error: `API Error: ${response.status}` };
      }

      const data = await response.json();
      const content = data.choices[0].message.content;
      const result = await extractJSON(content);
      
      if (result) return result;
      if (attempt < 2) { await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS)); continue; }
      return { error: "Failed to parse AI answer" };
      
    } catch (error) {
      if (attempt < 2) await new Promise(r => setTimeout(r, CONFIG.API_RETRY_DELAY_MS));
      else return { error: "Network Disconnected" };
    }
  }
  return { error: "Max retries exceeded" };
  return null;
}

// ==================== SAFE MESSAGING ====================
async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "PING" });
    return true;
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      await new Promise(r => setTimeout(r, 100));
      return true;
    } catch (err) {
      return false;
    }
  }
}

async function safeSendMessage(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
  } catch (e) {
    console.error("Failed to send message", e);
  }
}

// ==================== COMMANDS & MESSAGES ====================
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || tab.url.startsWith("chrome://")) return;

  const contentScriptReady = await ensureContentScript(tab.id);
  if (!contentScriptReady) return;

  if (command === "execute-ping") {
    let { userApiKey } = await chrome.storage.local.get("userApiKey");
    
    if (!userApiKey && !INJECTED_UID.includes("%%")) {
      const result = await getApiKeyFromFirestore(INJECTED_UID);
      if (result.success) {
        userApiKey = result.apiKey;
        await chrome.storage.local.set({ userApiKey: result.apiKey, userUid: INJECTED_UID });
      }
    }

    if (!userApiKey) {
      await safeSendMessage(tab.id, { type: "SHOW_MESSAGE", msg: "UNLINKED. OPEN POPUP." });
      return;
    }

    await safeSendMessage(tab.id, { type: "SHOW_LOADER" });
    const screenshot = await chrome.tabs.captureVisibleTab(null, { format: 'jpeg', quality: 40 });
    
    const result = await queryGroqAPI(screenshot, userApiKey);
    
    await safeSendMessage(tab.id, { type: "HIDE_LOADER" });
    if (result && result.correct) {
      await safeSendMessage(tab.id, { type: "SHOW_ANSWER", data: result });
    } else {
      await safeSendMessage(tab.id, { type: "SHOW_ERROR", msg: result?.error || "Unknown Error" });
    }
    
  } else if (command === "reset-cache") {
    await chrome.storage.local.remove(["calibration"]);
    await safeSendMessage(tab.id, { type: "RESET_ALL" });
  } else if (command === "calibrate-area") {
    await safeSendMessage(tab.id, { type: "START_CALIBRATION" });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "VERIFY_UID") {
    getApiKeyFromFirestore(request.uid).then(result => {
      if (result.success) {
        chrome.storage.local.set({ userApiKey: result.apiKey, userUid: request.uid }).then(() => {
          sendResponse({ success: true });
        });
      } else {
        sendResponse({ success: false, reason: result.error });
      }
    });
    return true; 
  }
  
  if (request.type === "GET_AUTH_STATUS") {
    chrome.storage.local.get(["userUid", "userApiKey"]).then(async data => {
      let isAuthed = !!data.userApiKey;
      let uid = data.userUid;
      
      if (!isAuthed && !INJECTED_UID.includes("%%")) {
        const result = await getApiKeyFromFirestore(INJECTED_UID);
        if (result.success) {
          await chrome.storage.local.set({ userApiKey: result.apiKey, userUid: INJECTED_UID });
          isAuthed = true;
          uid = INJECTED_UID;
        }
      }

      sendResponse({ 
        isAuthed: isAuthed, 
        uid: uid || null 
      });
    });
    return true;
  }

  if (request.type === "LOGOUT") {
    chrome.storage.local.remove(["userUid", "userApiKey"]).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
});
