import { INJECTED_UID } from './config/constants.js';
import { Logger } from './utils/logger.js';
import { withRetry } from './utils/retry.js';
import { getApiKeys } from './firebase/keys.js';
import { captureScreen } from './background/capture.js';
import { queryVisionAPI } from './api/groq.js';
import { Messenger } from './ui/messenger.js';

Logger.info("System", "Background Service Worker Initialized.");

chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || tab.url.startsWith("chrome://")) return;

  const contentScriptReady = await Messenger.ensureContentScript(tab.id);
  if (!contentScriptReady) return;

  if (command === "execute-ping") {
    Logger.info("Command", "execute-ping triggered by user.");

    if (INJECTED_UID.includes("%%")) {
      Logger.warn("Command", "Unlicensed UID detected. Aborting.");
      await Messenger.showMessage(tab.id, "UNLICENSED EXTENSION", true);
      return;
    }

    await Messenger.showLoader(tab.id);

    try {
      // 1. Fetch keys from Firebase
      Logger.debug("Pipeline", "Fetching API keys...");
      const apiKeys = await getApiKeys(INJECTED_UID);
      const activeKey = apiKeys[0]; // We use the primary key. If it rate limits, the backoff handles it.

      // 2. Capture Screenshot
      Logger.debug("Pipeline", "Capturing screenshot...");
      const screenshot = await captureScreen();

      // 3. Query Groq API with Exponential Backoff (Retry-After)
      Logger.debug("Pipeline", "Initiating API call with backoff logic...");
      const result = await withRetry(async (attempt) => {
        return await queryVisionAPI(screenshot, activeKey);
      });

      // 4. Return answer to UI
      Logger.info("Pipeline", "Execution complete. Sending answer to UI.");
      await Messenger.hideLoader(tab.id);
      await Messenger.showAnswer(tab.id, result);

    } catch (fatalError) {
      Logger.error("Fatal", "Pipeline crashed:", fatalError.message, fatalError.details || "");
      
      let errorMsg = "ERR 500";
      if (fatalError.type === "AUTH_ERROR") errorMsg = "ERR 403";
      else if (fatalError.type === "RATE_LIMIT") errorMsg = "ERR 429";
      else if (fatalError.type === "TIMEOUT") errorMsg = "ERR TIMEOUT";
      else if (fatalError.type === "NETWORK_ERROR") errorMsg = "ERR NET";
      
      await Messenger.hideLoader(tab.id);
      await Messenger.showError(tab.id, errorMsg);
    }
    
  } else if (command === "reset-cache") {
    Logger.info("Command", "reset-cache triggered.");
    await chrome.storage.local.remove(["calibration", "cachedApiKeys"]);
    await Messenger.safeSend(tab.id, { type: "RESET_ALL" });
  } else if (command === "calibrate-area") {
    Logger.info("Command", "calibrate-area triggered.");
    await Messenger.safeSend(tab.id, { type: "START_CALIBRATION" });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_AUTH_STATUS") {
    sendResponse({ 
      isAuthed: !INJECTED_UID.includes("%%"), 
      uid: INJECTED_UID.includes("%%") ? null : INJECTED_UID 
    });
    return true;
  }
});
