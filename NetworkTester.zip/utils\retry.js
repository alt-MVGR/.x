import { Logger } from './logger.js';

/**
 * Parses Retry-After header or applies exponential backoff
 */
export async function withRetry(operation, maxRetries = 3, initialDelay = 2000) {
  let attempt = 0;
  
  while (attempt < maxRetries) {
    try {
      return await operation(attempt);
    } catch (error) {
      attempt++;
      Logger.warn("Retry", `Operation failed (Attempt ${attempt}/${maxRetries}):`, error.message);
      
      if (!error.recoverable || attempt >= maxRetries) {
        throw error;
      }
      
      let delayMs = initialDelay * Math.pow(2, attempt - 1); // Exponential backoff

      if (error.retryAfter) {
        // Retry-After can be seconds (integer) or an HTTP Date string
        const parsedSeconds = parseInt(error.retryAfter, 10);
        if (!isNaN(parsedSeconds)) {
          delayMs = parsedSeconds * 1000;
        } else {
          const dateMs = new Date(error.retryAfter).getTime();
          if (!isNaN(dateMs)) {
            delayMs = Math.max(0, dateMs - Date.now());
          }
        }
      }
      
      Logger.info("Retry", `Waiting ${delayMs}ms before next attempt...`);
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }
}
