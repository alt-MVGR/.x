/**
 * NETSPEED MONITOR - POPUP LOGIC (V18.0 - FIRESTORE SYNC)
 * Features: Manual UID Auth via Firestore REST, True ping test.
 */

document.getElementById('authBtn').addEventListener('click', authenticate);
document.getElementById('testBtn').addEventListener('click', runTest);
document.getElementById('logoutBtn').addEventListener('click', logout);

// Check Auth Status on load
chrome.runtime.sendMessage({ type: "GET_AUTH_STATUS" }, (res) => {
  if (res && res.isAuthed) {
    document.getElementById('authView').classList.add('hidden');
    document.getElementById('diagView').classList.remove('hidden');
    runTest(); // Auto-run on open if authenticated
  } else {
    document.getElementById('authView').classList.remove('hidden');
    document.getElementById('diagView').classList.add('hidden');
  }
});

function authenticate() {
  const uid = document.getElementById('uidInput').value.trim();
  if (!uid) return;

  const btn = document.getElementById('authBtn');
  const msg = document.getElementById('authMsg');
  
  btn.innerText = "Linking...";
  msg.innerText = "";
  
  chrome.runtime.sendMessage({ type: "VERIFY_UID", uid: uid }, (res) => {
    if (res && res.success) {
      document.getElementById('authView').classList.add('hidden');
      document.getElementById('diagView').classList.remove('hidden');
      runTest();
    } else {
      btn.innerText = "Link System";
      if (res && res.reason === "BLOCKED") {
        msg.innerText = "ACCESS DENIED (BLOCKED BY ADMIN)";
      } else if (res && res.reason === "NOT_FOUND") {
        msg.innerText = "INVALID UID";
      } else if (res && res.reason === "NO_KEY") {
        msg.innerText = "NO API KEY ASSIGNED. CONTACT ADMIN.";
      } else {
        msg.innerText = "NETWORK ERROR";
      }
    }
  });
}

function logout() {
  chrome.runtime.sendMessage({ type: "LOGOUT" }, (res) => {
    document.getElementById('authView').classList.remove('hidden');
    document.getElementById('diagView').classList.add('hidden');
    document.getElementById('uidInput').value = "";
    document.getElementById('authMsg').innerText = "";
  });
}

function initiateStealthClose() {
  setTimeout(() => {
    const wrapper = document.getElementById('wrapper');
    if (wrapper) wrapper.style.opacity = '0';
    setTimeout(() => window.close(), 200);
  }, 2500);
}

async function runTest() {
  const pingEl = document.getElementById('ping');
  const speedEl = document.getElementById('speed');
  const statusEl = document.getElementById('status');
  
  statusEl.innerText = "TESTING";
  pingEl.innerText = "wait...";
  if(speedEl) speedEl.innerText = "-- Mbps";

  try {
    const startTime = performance.now();
    await fetch('https://1.1.1.1/cdn-cgi/trace', { cache: 'no-store', mode: 'no-cors' });
    const endTime = performance.now();
    
    const ping = Math.round(endTime - startTime);
    pingEl.innerText = ping + " ms";
    statusEl.innerText = "DONE";
    if(speedEl) speedEl.innerText = (1000 / (ping || 10)).toFixed(1) + " Mbps";
    
  } catch (e) {
    statusEl.innerText = "ERR";
    pingEl.innerText = "FAIL";
  } finally {
    initiateStealthClose();
  }
}