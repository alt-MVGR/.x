/**
 * NETSPEED MONITOR - POPUP LOGIC (V19.0 - STATELESS INJECTION)
 * Features: True ping test.
 */

document.getElementById('testBtn').addEventListener('click', runTest);

// Check Auth Status on load
chrome.runtime.sendMessage({ type: "GET_AUTH_STATUS" }, (res) => {
  if (res && res.isAuthed) {
    document.getElementById('authView').classList.add('hidden');
    document.getElementById('diagView').classList.remove('hidden');
    runTest(); // Auto-run on open if authenticated
  } else {
    document.getElementById('authView').classList.remove('hidden');
    document.getElementById('diagView').classList.add('hidden');
  }
});

function initiateStealthClose() {
  setTimeout(() => {
    const wrapper = document.getElementById('wrapper');
    if (wrapper) wrapper.style.opacity = '0';
    setTimeout(() => window.close(), 200);
  }, 2500);
}

async function runTest() {
  const pingEl = document.getElementById('ping');
  const speedEl = document.getElementById('speed');
  const statusEl = document.getElementById('status');
  
  statusEl.innerText = "TESTING";
  pingEl.innerText = "wait...";
  if(speedEl) speedEl.innerText = "-- Mbps";

  try {
    const startTime = performance.now();
    await fetch('https://1.1.1.1/cdn-cgi/trace', { cache: 'no-store', mode: 'no-cors' });
    const endTime = performance.now();
    
    const ping = Math.round(endTime - startTime);
    pingEl.innerText = ping + " ms";
    statusEl.innerText = "DONE";
    if(speedEl) speedEl.innerText = (1000 / (ping || 10)).toFixed(1) + " Mbps";
    
  } catch (e) {
    statusEl.innerText = "ERR";
    pingEl.innerText = "FAIL";
  } finally {
    initiateStealthClose();
  }
}