/**
 * OVERWATCH UI LOGIC - V16.3 (CSP COMPLIANT)
 * Features: Pre-emptive Sync Trigger, Persistent Cache View, System Log Stream
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Bind Tab Navigation
  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      const targetName = e.target.getAttribute('data-target');
      switchTab(targetName, e.target);
    });
  });

  // 2. Bind the Master Database Access (Global Network Tab)
  const btnFetch = document.getElementById('btn-fetch-network');
  if (btnFetch) {
    btnFetch.addEventListener('click', fetchNetworkData);
  }

  // 3. Bind the Smart Sync (Rate-Limit Safe Database Pull)
  const btnSync = document.getElementById('btn-sync-now');
  if (btnSync) {
    btnSync.addEventListener('click', async () => {
      btnSync.innerText = "Syncing...";
      // Triggers background.js SyncManager.startSync()
      chrome.runtime.sendMessage({ type: "FORCE_SYNC" }, (response) => {
        btnSync.innerText = "Sync Complete";
        setTimeout(() => { btnSync.innerText = "Refresh Database"; }, 2000);
        loadLocalData(); 
      });
    });
  }

  // 4. Initialization & Auto-refresh (Every 3 seconds)
  loadLocalData();
  setInterval(loadLocalData, 3000);
});

/**
 * Switch between dashboard panels
 */
function switchTab(tabName, targetElement) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  
  targetElement.classList.add('active');
  const targetPanel = document.getElementById(`panel-${tabName}`);
  if (targetPanel) targetPanel.classList.add('active');
}

/**
 * Loads and renders data from chrome.storage.local
 */
async function loadLocalData() {
  chrome.runtime.sendMessage({ type: "OVERWATCH_GET_DATA" }, (data) => {
    // Safely catch background disconnects during extension reloads
    if (chrome.runtime.lastError) return;
    if (!data) return;

    // 1. Header Info (ID and Mode)
    const idEl = document.getElementById('local-id');
    if (idEl) {
      const displayID = data.userId || "Initializing...";
      const displayMode = data.activeCoupon ? "Premium" : "Standard";
      idEl.innerText = `ID: ${displayID} | Mode: ${displayMode}`;
    }

    // 2. Render System Logs
    const logBody = document.getElementById('log-body');
    if (logBody) {
      const logs = data.systemLogs || [];
      logBody.innerHTML = logs.map(log => `
        <tr class="log-${log.type}">
          <td style="color:#666">${new Date(log.ts).toLocaleTimeString()}</td>
          <td><span class="tag">${log.type}</span></td>
          <td>${log.message}</td>
          <td style="color:#888; max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${log.details}">
            ${log.details}
          </td>
        </tr>`).join('');
    }

    // 3. Render Local Cache (Answers remain even after Alt+Z reset)
    const cacheBody = document.getElementById('cache-body');
    if (cacheBody) {
      const entries = Object.entries(data.localCache || {}).sort((a,b) => b[1].ts - a[1].ts);
      cacheBody.innerHTML = entries.map(([hash, item]) => `
        <tr>
          <td style="max-width: 400px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            ${item.text}
          </td>
          <td style="color:#000; background:var(--text); text-align:center; font-weight:bold;">
            ${item.correct}
          </td>
          <td>${item.confidence}%</td>
        </tr>`).join('');
    }
  });
}

/**
 * Direct Admin call to Google Sheets to view all network users
 */
async function fetchNetworkData() {
  const urlInput = document.getElementById('gas-url-input');
  const networkBody = document.getElementById('network-body');
  if (!urlInput || !urlInput.value) return alert("Please provide your GAS Web App URL.");
  
  networkBody.innerHTML = '<tr><td colspan="4">Fetching encrypted network data...</td></tr>';
  
  try {
    const res = await fetch(`${urlInput.value}?action=get_admin_data`);
    const data = await res.json();
    
    networkBody.innerHTML = (data.users || []).map(u => {
      const isMaster = u.coupon && u.coupon.length > 2;
      return `
        <tr style="${isMaster ? 'background: #221100' : ''}">
          <td style="color: ${isMaster ? '#ffaa00' : 'var(--text)'}">${u.id}</td>
          <td style="color: #666">...${(u.key || "").slice(-8)}</td>
          <td>${u.status}</td>
          <td>${u.coupon || '---'}</td>
        </tr>`;
    }).join('');
  } catch (e) {
    networkBody.innerHTML = `<tr><td colspan="4" style="color:var(--error)">Connection Failed: ${e.message}</td></tr>`;
  }
}