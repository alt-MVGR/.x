import { ScreenshotError } from '../utils/errors.js';
import { Logger } from '../utils/logger.js';
import { CONFIG } from '../config/constants.js';

/**
 * Handles capturing the visible tab.
 * Wraps it in a try/catch to prevent Uncaught Promise Rejections if activeTab is lost.
 */
export async function captureScreen() {
  try {
    Logger.debug("Capture", `Initiating captureVisibleTab with quality ${CONFIG.IMAGE_QUALITY}...`);
    
    // We pass null for windowId to capture the current window
    const screenshot = await chrome.tabs.captureVisibleTab(null, { 
      format: 'jpeg', 
      quality: CONFIG.IMAGE_QUALITY 
    });

    if (!screenshot || typeof screenshot !== 'string' || !screenshot.startsWith('data:image')) {
      throw new ScreenshotError("Capture returned invalid data.");
    }

    // Basic integrity check
    if (screenshot.length < 1000) {
      throw new ScreenshotError("Captured image is too small, likely corrupted or empty.");
    }

    Logger.info("Capture", `Screenshot captured successfully. Size: ~${Math.round(screenshot.length / 1024)}KB`);
    return screenshot;
    
  } catch (error) {
    Logger.error("Capture", "captureVisibleTab failed:", error.message);
    
    // Often happens if DevTools is focused, or on a restricted chrome:// page, or if activeTab permission was lost
    throw new ScreenshotError(`Failed to capture screenshot: ${error.message}`);
  }
}
