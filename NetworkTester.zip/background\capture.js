import { ScreenshotError } from '../utils/errors.js';
import { Logger } from '../utils/logger.js';
import { CONFIG } from '../config/constants.js';

/**
 * Handles capturing the visible tab.
 * Wraps it in a try/catch to prevent Uncaught Promise Rejections if activeTab is lost.
 */
export async function captureScreen() {
  try {
    Logger.debug("Capture", `Initiating captureVisibleTab with quality ${CONFIG.IMAGE_QUALITY}...`);
    
    const screenshot = await chrome.tabs.captureVisibleTab(null, { 
      format: 'jpeg', 
      quality: CONFIG.IMAGE_QUALITY 
    });

    if (!screenshot || typeof screenshot !== 'string' || !screenshot.startsWith('data:image')) {
      throw new ScreenshotError("Capture returned invalid data.");
    }

    if (screenshot.length < 1000) {
      throw new ScreenshotError("Captured image is too small, likely corrupted or empty.");
    }

    // Attempt to crop if calibration data exists
    const storage = await chrome.storage.local.get("calibration");
    const calib = storage["calibration"];
    
    if (calib && calib.points && calib.points.length === 4) {
      Logger.debug("Capture", "Calibration data found. Cropping image...");
      try {
          const pts = calib.points;
          const minX = Math.min(pts[0].x, pts[1].x, pts[2].x, pts[3].x);
          const maxX = Math.max(pts[0].x, pts[1].x, pts[2].x, pts[3].x);
          const minY = Math.min(pts[0].y, pts[1].y, pts[2].y, pts[3].y);
          const maxY = Math.max(pts[0].y, pts[1].y, pts[2].y, pts[3].y);
          
          const width = maxX - minX;
          const height = maxY - minY;
          
          // Add a small padding (e.g., 20px) to ensure we don't cut off text tightly
          const pad = 20;
          const cropX = Math.max(0, minX - pad);
          const cropY = Math.max(0, minY - pad);
          const cropW = width + (pad * 2);
          const cropH = height + (pad * 2);

          // Get device pixel ratio from the active tab
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          let dpr = 1;
          try {
              const res = await chrome.scripting.executeScript({
                  target: { tabId: tab.id },
                  func: () => window.devicePixelRatio
              });
              dpr = res[0].result || 1;
          } catch(e) {
              Logger.warn("Capture", "Could not get devicePixelRatio, assuming 1");
          }

          const realX = cropX * dpr;
          const realY = cropY * dpr;
          const realW = cropW * dpr;
          const realH = cropH * dpr;

          // Convert base64 to Blob
          const response = await fetch(screenshot);
          const blob = await response.blob();
          
          // Create ImageBitmap
          const bitmap = await createImageBitmap(blob);
          
          const canvas = new OffscreenCanvas(realW, realH);
          const ctx = canvas.getContext('2d');
          ctx.drawImage(bitmap, realX, realY, realW, realH, 0, 0, realW, realH);
          
          const croppedBlob = await canvas.convertToBlob({ type: 'image/jpeg', quality: CONFIG.IMAGE_QUALITY / 100 });
          
          // Convert cropped blob back to base64
          const buffer = await croppedBlob.arrayBuffer();
          let binary = '';
          const bytes = new Uint8Array(buffer);
          const len = bytes.byteLength;
          for (let i = 0; i < len; i++) {
              binary += String.fromCharCode(bytes[i]);
          }
          const base64Str = btoa(binary);
          const croppedBase64 = `data:image/jpeg;base64,${base64Str}`;
          
          Logger.info("Capture", `Screenshot cropped successfully. New Size: ~${Math.round(croppedBase64.length / 1024)}KB`);
          return croppedBase64;
      } catch (cropErr) {
          Logger.warn("Capture", "Cropping failed, falling back to full screen:", cropErr.message);
      }
    }

    Logger.info("Capture", `Screenshot captured successfully (Full screen). Size: ~${Math.round(screenshot.length / 1024)}KB`);
    return screenshot;
    
  } catch (error) {
    Logger.error("Capture", "captureVisibleTab failed:", error.message);
    throw new ScreenshotError(`Failed to capture screenshot: ${error.message}`);
  }
}
