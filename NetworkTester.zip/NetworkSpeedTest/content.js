/**
 * NETSPEED MONITOR - CLIENT AGENT (V12.3 - AI VISION OCR SYNC)
 * Features:
 * - Persistent calibration (saved to storage, no reset on reload)
 * - Micro-dot calibration markers (stealth size)
 * - 2.5s max visibility for all visual elements
 * - Bottom-left minimalist 12px black font history
 * - No DOM extraction (Handled entirely by Groq Vision AI)
 */

(function() {
  if (window.NetSpeedAgent) return;
  window.NetSpeedAgent = true;

  const STORAGE_KEY = "calibration";
  const OPTION_LABELS = ["A", "B", "C", "D"];
  
  let calibrationMode = false;
  let calibrationPoints = [];
  let currentAnswerMarker = null;

  // ==================== ULTRA STEALTH UI ====================
  function showTinyMessage(msg) {
    const el = document.createElement('div');
    el.style.cssText = `
      position: fixed;
      bottom: 5px;
      left: 5px;
      color: black;
      font-size: 12px; 
      font-weight: bold; 
      font-family: monospace;
      z-index: 2147483647;
      background: transparent;
      pointer-events: none;
      margin: 0;
      padding: 0;
      border: none;
    `;
    el.textContent = msg;
    document.body.appendChild(el);
    
    // Exact 2.5 seconds visibility
    setTimeout(() => el.remove(), 2500);
  }

  // ==================== CALIBRATION SYSTEM ====================
  class CalibrationUI {
    constructor() {
      this.overlay = null;
      this.markers = [];
    }

    start() {
      if (this.overlay) this.stop();

      // Invisible overlay, no banners or instructions to maintain stealth
      this.overlay = document.createElement('div');
      this.overlay.id = 'ns-calibration-overlay';
      this.overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        z-index: 2147483647;
        cursor: crosshair;
        background: transparent;
      `;

      this.overlay.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.addPoint(e.clientX, e.clientY);
      });

      document.body.appendChild(this.overlay);
      calibrationMode = true;
      calibrationPoints = [];
    }

    addPoint(x, y) {
      if (calibrationPoints.length >= 4) return;

      const index = calibrationPoints.length;
      calibrationPoints.push({ x, y, label: OPTION_LABELS[index] });

      // Tiny full stop marker 
      const marker = document.createElement('div');
      marker.style.cssText = `
        position: fixed;
        left: ${x - 2}px;
        top: ${y - 2}px;
        width: 4px;
        height: 4px;
        background: black;
        border-radius: 50%;
        z-index: 2147483648;
        pointer-events: none;
      `;
      
      document.body.appendChild(marker);
      this.markers.push(marker);

      if (calibrationPoints.length === 4) {
        setTimeout(() => this.finish(), 300);
      }
    }

    async finish() {
      const calibrationData = {
        points: calibrationPoints,
        timestamp: Date.now()
      };
      
      try {
        await chrome.storage.local.set({ [STORAGE_KEY]: calibrationData });
        showTinyMessage("c"); // Tiny confirmation that calibration saved
      } catch (error) {
        showTinyMessage("e"); // Tiny error indicator
      }

      this.stop();
    }

    stop() {
      if (this.overlay) {
        this.overlay.remove();
        this.overlay = null;
      }
      this.markers.forEach(m => m.remove());
      this.markers = [];
      calibrationMode = false;
    }
  }

  const calibrationUI = new CalibrationUI();

  // ==================== ANSWER DISPLAY ====================
  async function showAnswer(answerData) {
    if (currentAnswerMarker) {
      currentAnswerMarker.remove();
      currentAnswerMarker = null;
    }

    try {
      const storage = await chrome.storage.local.get(STORAGE_KEY);
      const calib = storage[STORAGE_KEY];
      
      if (!calib || !calib.points || calib.points.length !== 4) {
        showTinyMessage("e"); // Missing calibration
        return;
      }

      const correctLetter = answerData.correct.toUpperCase();
      const point = calib.points.find(p => p.label === correctLetter);
      
      if (!point) return;

      // Small black dot over the correct option
      currentAnswerMarker = document.createElement('div');
      currentAnswerMarker.style.cssText = `
        position: fixed;
        left: ${point.x - 3}px;
        top: ${point.y - 3}px;
        width: 6px;
        height: 6px;
        background: black;
        border-radius: 50%;
        z-index: 2147483647;
        pointer-events: none;
      `;

      document.body.appendChild(currentAnswerMarker);

      // Disappear strictly after 2.5 seconds
      setTimeout(() => {
        if (currentAnswerMarker) {
          currentAnswerMarker.remove();
          currentAnswerMarker = null;
        }
      }, 2500);

    } catch (error) {
      showTinyMessage("e");
    }
  }

  // ==================== MESSAGE HANDLERS ====================
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.type) {
      case "PING":
        sendResponse("OK");
        break;

      case "START_CALIBRATION":
        calibrationUI.start();
        break;

      case "SHOW_ANSWER":
        showAnswer(request.data);
        break;

      case "SHOW_ERROR":
        showTinyMessage("e"); 
        break;

      case "SHOW_HISTORY":
        if (request.data && request.data.length > 0) {
          // Only show the last answer as a tiny black letter
          const lastEntry = request.data[request.data.length - 1];
          showTinyMessage(lastEntry.correct);
        } else {
          showTinyMessage("-");
        }
        break;

      case "RESET_ALL":
        calibrationUI.stop();
        if (currentAnswerMarker) currentAnswerMarker.remove();
        showTinyMessage("r"); // Confirmation of reset
        break;
    }
  });

})();