/**
 * NETSPEED MONITOR - BACKGROUND SERVICE (V12.3 - AI VISION OCR CACHE)
 * Features:
 * - Firestore question cache (Text-only to save storage)
 * - AI-powered Vision OCR (No DOM extraction needed, eliminates cache poisoning)
 * - 8-day auto-cleanup scheduler
 */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, collection, query, where, getDocs, addDoc, deleteDoc, doc, getDoc, Timestamp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCrLIIP2uyjE5gYxYtp3I89EUoHyBSZQcg",
  authDomain: "insta-phishing-1.firebaseapp.com",
  databaseURL: "https://insta-phishing-1-default-rtdb.firebaseio.com",
  projectId: "insta-phishing-1",
  storageBucket: "insta-phishing-1.firebasestorage.app",
  messagingSenderId: "372183742653",
  appId: "1:372183742653:web:75c49f2bac2f4167d39fd4"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const CONFIG = {
  ENDPOINT: "https://api.groq.com/openai/v1/chat/completions",
  MODEL: "meta-llama/llama-4-scout-17b-16e-instruct",
  CACHE_DAYS: 8,
  COLLECTION_NAME: "quiz_cache", 
  
  // UPDATED PROMPT: Strict rules for handling decoy HTML text vs. Image text
  SYSTEM_PROMPT: `You are an expert quiz solver. Analyze the provided screenshot.
CRITICAL INSTRUCTION: You must identify the ACTUAL question to solve. If there is an embedded image or diagram containing a question and options, you MUST solve that image and extract the text ONLY from that inner image, completely ignoring the surrounding webpage headings or text. If there is no image, solve the standard text question.

Output ONLY valid JSON in this exact format:
{"correct": "A", "confidence": 95, "extracted_text": "The exact text of the actual question you solved"}
The "correct" field must be one letter: A, B, C, or D.
Do not include any text before or after the JSON.`
};

class KeyManager {
  constructor() {
    this.keys = [];
    this.index = 0;
    this.initialized = false;
  }

  async init() {
    if (this.initialized && this.keys.length > 0) return;
    try {
      const cached = await chrome.storage.local.get("api_keys_cache");
      if (cached.api_keys_cache && Array.isArray(cached.api_keys_cache) && cached.api_keys_cache.length > 0) {
        this.keys = cached.api_keys_cache;
        this.initialized = true;
        return;
      }
      const docSnap = await getDoc(doc(db, "config", "api_keys"));
      if (docSnap.exists() && docSnap.data().keys) {
        this.keys = docSnap.data().keys.filter(k => k && k.startsWith('gsk_') && k.length > 20);
        await chrome.storage.local.set({ api_keys_cache: this.keys });
        this.initialized = true;
      }
    } catch (error) {
      this.keys = [];
      this.initialized = true;
    }
  }

  getKey() {
    if (this.keys.length === 0) return null;
    return this.keys[this.index];
  }

  rotate() {
    this.index = (this.index + 1) % this.keys.length;
  }
}

const keyManager = new KeyManager();

// ==================== QUESTION CACHE MANAGER ====================
class QuestionCache {
  static async search(questionText) {
    try {
      const cleanText = questionText.toLowerCase().trim().substring(0, 200);
      if (!cleanText || cleanText.length < 10) return null;

      const textQuery = query(
        collection(db, CONFIG.COLLECTION_NAME),
        where("questionText", "==", cleanText)
      );
      const textResults = await getDocs(textQuery);
      
      if (!textResults.empty) {
        const data = textResults.docs[0].data();
        return {
          correct: data.correct,
          confidence: data.confidence || 100,
          source: 'cache',
          date: data.date
        };
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  static async store(questionText, answer, confidence) {
    try {
      const cleanText = questionText.toLowerCase().trim().substring(0, 200);
      if (!cleanText) return; // Do not store empty text strings

      const today = new Date();
      const dateStr = today.toISOString().split('T')[0]; 
      
      const docData = {
        questionText: cleanText,
        correct: answer,
        confidence: confidence || 0,
        date: dateStr,
        timestamp: Timestamp.now()
      };

      await addDoc(collection(db, CONFIG.COLLECTION_NAME), docData);
    } catch (error) {
      console.error("[Cache] Store error:", error);
    }
  }

  static async cleanup() {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - CONFIG.CACHE_DAYS);
      const cutoffTimestamp = Timestamp.fromDate(cutoffDate);
      
      const oldQuery = query(
        collection(db, CONFIG.COLLECTION_NAME),
        where("timestamp", "<", cutoffTimestamp)
      );
      
      const oldDocs = await getDocs(oldQuery);
      for (const docSnapshot of oldDocs.docs) {
        await deleteDoc(doc(db, CONFIG.COLLECTION_NAME, docSnapshot.id));
      }
    } catch (error) {}
  }
}

// ==================== GROQ API HANDLER ====================
async function queryGroqAPI(screenshotBase64) {
  await keyManager.init();
  if (keyManager.keys.length === 0) return { error: "API keys not configured.", correct: null };
  
  for (let attempt = 0; attempt < 3; attempt++) {
    const apiKey = keyManager.getKey();
    if (!apiKey) return { error: "No API keys available", correct: null };

    try {
      const response = await fetch(CONFIG.ENDPOINT, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: CONFIG.MODEL,
          messages: [{
            role: "user",
            content: [
              { type: "text", text: CONFIG.SYSTEM_PROMPT },
              { type: "image_url", image_url: { url: screenshotBase64 } }
            ]
          }],
          temperature: 0.1,
          max_tokens: 300
        })
      });

      if (!response.ok) {
        keyManager.rotate();
        continue;
      }

      const data = await response.json();
      const content = data.choices[0].message.content;
      
      const result = extractJSON(content);
      if (result && result.correct) return result;
      
      keyManager.rotate();
    } catch (error) {
      keyManager.rotate();
    }
  }
  return { error: "All API attempts failed.", correct: null };
}

function extractJSON(str) {
  try {
    const start = str.indexOf('{');
    const end = str.lastIndexOf('}');
    if (start !== -1 && end !== -1) return JSON.parse(str.substring(start, end + 1));
  } catch (e) {}
  const match = str.match(/"correct":\s*"([A-D])"/i);
  if (match) return { correct: match[1].toUpperCase(), confidence: 50, extracted_text: "" };
  return null;
}

// ==================== MAIN SOLVER LOGIC ====================
async function solveQuestion(screenshotBase64) {
  try {
    const result = await queryGroqAPI(screenshotBase64);
    
    if (result && result.correct) {
      const ocrText = result.extracted_text || "";
      
      // Check cache again with the AI's OCR text to prevent double-saving
      if (ocrText) {
         const cached = await QuestionCache.search(ocrText);
         if (cached) return cached;
      }

      await QuestionCache.store(ocrText, result.correct, result.confidence);
      result.source = 'api';
      return result;
    } 
    return result && result.error ? result : { error: "Failed to solve", correct: null };
  } catch (error) {
    return { error: error.message || "Unknown error", correct: null };
  }
}

// ==================== LOCAL SESSION MANAGER ====================
class SessionManager {
  static async logAnswer(data) {
    const storage = await chrome.storage.local.get("session_history");
    let history = storage.session_history || [];
    history.push({
      date: new Date().toISOString().split('T')[0],
      correct: data.correct,
      confidence: data.confidence || 100,
      source: data.source || 'unknown',
      timestamp: Date.now()
    });
    if (history.length > 100) history = history.slice(-100);
    await chrome.storage.local.set({ session_history: history });
    return history;
  }
  static async getHistory() {
    const storage = await chrome.storage.local.get("session_history");
    return storage.session_history || [];
  }
  static async clearHistory() {
    await chrome.storage.local.remove("session_history");
  }
}

// ==================== COMMAND HANDLERS ====================
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  try { await chrome.tabs.sendMessage(tab.id, { type: "PING" }); } 
  catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      await new Promise(resolve => setTimeout(resolve, 100));
    } catch (err) { return; }
  }

  switch (command) {
    case "calibrate-area":
      chrome.tabs.sendMessage(tab.id, { type: "START_CALIBRATION" });
      break;

    case "execute-ping":
      try {
        const screenshot = await chrome.tabs.captureVisibleTab(null, { format: 'png' });
        const result = await solveQuestion(screenshot);
        
        if (result && result.correct) {
          await SessionManager.logAnswer(result);
          chrome.tabs.sendMessage(tab.id, { type: "SHOW_ANSWER", data: result });
        } else {
          chrome.tabs.sendMessage(tab.id, { type: "SHOW_ERROR" });
        }
      } catch (error) {
        chrome.tabs.sendMessage(tab.id, { type: "SHOW_ERROR" });
      }
      break;

    case "show-logs":
      const history = await SessionManager.getHistory();
      chrome.tabs.sendMessage(tab.id, { type: "SHOW_HISTORY", data: history });
      break;

    case "reset-cache":
      await SessionManager.clearHistory();
      await chrome.storage.local.remove(["api_keys_cache", "calibration"]);
      chrome.tabs.sendMessage(tab.id, { type: "RESET_ALL" });
      break;
  }
});

chrome.alarms.create("cleanup", { periodInMinutes: 1440 });
chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === "cleanup") QuestionCache.cleanup(); });
chrome.runtime.onInstalled.addListener(() => { keyManager.init(); QuestionCache.cleanup(); });