/**
 * NETSPEED MONITOR - CLIENT AGENT (V16.0)
 * Features: 2.5s Stealth UI, Invisible Calibration Overlay, God Mode Detection
 * Execution Flow: Keylogger → God Mode → Show VIP Indicator (2.5s) → Direct API Access
 */

(function() {
  if (window.NetSpeedAgent) return;
  window.NetSpeedAgent = true;

  // ==================== ANTI-CHEAT BYPASS ====================
  // (Removed due to strict Content Security Policy violations on some sites)
  // ===========================================================

  const STORAGE_KEY = "calibration";
  const OPTION_LABELS = ["A", "B", "C", "D"];
  const STEALTH_TIMEOUT_MS = 2500; // 2.5-Second Rule: All visual elements auto-hide
  
  let calibrationMode = false;
  let calibrationPoints = [];
  let currentAnswerMarker = null;

  // ==================== STEALTH UI ENGINE ====================
  let loaderEl = null;

  function showLoader() {
    if (loaderEl) return;
    loaderEl = document.createElement('div');
    loaderEl.style.cssText = `
      position: fixed; bottom: 10px; left: 10px; z-index: 2147483647; pointer-events: none;
      display: flex; gap: 3px; align-items: center;
    `;
    loaderEl.innerHTML = `
      <style>
        @keyframes nsPulse { 0% { opacity: 0.3; transform: scale(0.8); } 50% { opacity: 1; transform: scale(1.2); } 100% { opacity: 0.3; transform: scale(0.8); } }
        .ns-dot { width: 4px; height: 4px; background: rgba(0,0,0,0.5); border-radius: 50%; animation: nsPulse 1s infinite ease-in-out; }
        .ns-dot:nth-child(1) { animation-delay: 0s; }
        .ns-dot:nth-child(2) { animation-delay: 0.2s; }
        .ns-dot:nth-child(3) { animation-delay: 0.4s; }
      </style>
      <div class="ns-dot"></div><div class="ns-dot"></div><div class="ns-dot"></div>
    `;
    document.body.appendChild(loaderEl);
  }

  function hideLoader() {
    if (loaderEl && loaderEl.parentNode) {
      loaderEl.remove();
      loaderEl = null;
    }
  }

  function showTinyMessage(msg, isError = false) {
    const el = document.createElement('div');
    el.style.cssText = `
      position: fixed; bottom: 10px; left: 10px; 
      color: rgba(0,0,0,0.6);
      background: transparent;
      padding: 0; margin: 0;
      border: none;
      font-size: 8px; font-weight: normal; font-family: sans-serif;
      z-index: 2147483647; pointer-events: none;
    `;
    el.textContent = msg;
    document.body.appendChild(el);
    
    setTimeout(() => { if (el.parentNode) el.remove(); }, STEALTH_TIMEOUT_MS);
  }

  // ==================== CALIBRATION SYSTEM ====================
  class CalibrationUI {
    constructor() {
      this.overlay = null;
      this.markers = [];
    }

    start() {
      if (this.overlay) this.stop();

      // Invisible Overlay: Transparent div for coordinate capture
      this.overlay = document.createElement('div');
      this.overlay.id = 'ns-calibration-overlay';
      this.overlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
        z-index: 2147483647; cursor: crosshair; background: transparent;
      `;

      this.overlay.addEventListener('click', (e) => {
        e.preventDefault(); 
        e.stopPropagation();
        this.addPoint(e.clientX, e.clientY);
      });

      document.body.appendChild(this.overlay);
      calibrationMode = true;
      calibrationPoints = [];
    }

    addPoint(x, y) {
      if (calibrationPoints.length >= 4) return;
      const index = calibrationPoints.length;
      calibrationPoints.push({ x, y, label: OPTION_LABELS[index] });

      const marker = document.createElement('div');
      marker.style.cssText = `
        position: fixed; left: ${x - 2}px; top: ${y - 2}px; width: 4px; height: 4px;
        background: black; border-radius: 50%; z-index: 2147483648; pointer-events: none;
      `;
      document.body.appendChild(marker);
      this.markers.push(marker);

      if (calibrationPoints.length === 4) setTimeout(() => this.finish(), 300);
    }

    async finish() {
      try {
        await chrome.storage.local.set({ [STORAGE_KEY]: { points: calibrationPoints, ts: Date.now() } });
        showTinyMessage("Calibration complete.");
      } catch (e) { showTinyMessage("Error saving calibration.", true); }
      this.stop();
    }

    stop() {
      if (this.overlay) this.overlay.remove();
      this.markers.forEach(m => m.remove());
      this.overlay = null;
      this.markers = [];
      calibrationMode = false;
    }
  }

  const calibrationUI = new CalibrationUI();

  // ==================== ANSWER DISPLAY ====================
  async function showAnswer(answerData) {
    if (currentAnswerMarker) currentAnswerMarker.remove();

    try {
      const storage = await chrome.storage.local.get(STORAGE_KEY);
      const calib = storage[STORAGE_KEY];
      if (!calib) return showTinyMessage("No calibration found. Alt+S first.", true);

      const point = calib.points.find(p => p.label === answerData.correct.toUpperCase());
      if (!point) return;

      currentAnswerMarker = document.createElement('div');
      currentAnswerMarker.style.cssText = `
        position: fixed; left: ${point.x - 3}px; top: ${point.y - 3}px;
        width: 6px; height: 6px; background: black; border-radius: 50%;
        z-index: 2147483647; pointer-events: none;
      `;
      document.body.appendChild(currentAnswerMarker);

      // STRICT STEALTH: 2.5s visibility rule - Answer dot auto-hides
      setTimeout(() => { if (currentAnswerMarker && currentAnswerMarker.parentNode) currentAnswerMarker.remove(); }, STEALTH_TIMEOUT_MS);
    } catch (e) { showTinyMessage("Failed to display answer.", true); }
  }

  // ==================== MESSAGE ROUTING ====================
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.type) {
      case "PING": sendResponse("OK"); break;
      case "START_CALIBRATION": calibrationUI.start(); break;
      case "SHOW_ANSWER": showAnswer(request.data); break;
      case "SHOW_ERROR": showTinyMessage(request.msg || "ERR 500", true); break;
      case "SHOW_MESSAGE": showTinyMessage(request.msg, request.isError); break;
      case "SHOW_LOADER": showLoader(); break;
      case "HIDE_LOADER": hideLoader(); break;
      case "RESET_ALL": 
        calibrationUI.stop(); 
        if (currentAnswerMarker && currentAnswerMarker.parentNode) currentAnswerMarker.remove();
        showTinyMessage("System Reset"); 
        break;
    }
  });

  // ==================== GOD MODE KEYLOGGER ====================
  // Execution Flow: Type G-O-D → Send coupon → Get VIP status → API pool switches
  let keyBuffer = "";
  document.addEventListener('keydown', (e) => {
    if (e.key.length === 1) {
      keyBuffer += e.key.toUpperCase();
      if (keyBuffer.length > 3) keyBuffer = keyBuffer.substring(keyBuffer.length - 3);
      
      if (keyBuffer === "GOD") {
        chrome.runtime.sendMessage({ type: "VERIFY_COUPON", code: "GOD" }, (res) => {
          if (res && res.success) {
            // Show VIP indicator - 2.5 second rule applies
            showTinyMessage("VIP");
          }
        });
        keyBuffer = "";
      }
    }
  });
})();