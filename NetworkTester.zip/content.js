/**
 * NETSPEED MONITOR - CLIENT AGENT (V16.0)
 * Features: 2.5s Stealth UI, Invisible Calibration Overlay, God Mode Detection
 * Execution Flow: Keylogger → God Mode → Show VIP Indicator (2.5s) → Direct API Access
 */

(function() {
  if (window.NetSpeedAgent) return;
  window.NetSpeedAgent = true;

  // ==================== ANTI-CHEAT BYPASS ====================
  // Inject script into MAIN world to intercept and stop anti-cheat events
  const bypassScript = document.createElement('script');
  bypassScript.textContent = `
    window.addEventListener('contextmenu', e => e.stopPropagation(), true);
    window.addEventListener('keydown', e => e.stopPropagation(), true);
    console.log("Anti-cheat mechanisms neutralized.");
  `;
  (document.head || document.documentElement).appendChild(bypassScript);
  bypassScript.remove();
  // ===========================================================

  const STORAGE_KEY = "calibration";
  const OPTION_LABELS = ["A", "B", "C", "D"];
  const STEALTH_TIMEOUT_MS = 2500; // 2.5-Second Rule: All visual elements auto-hide
  
  let calibrationMode = false;
  let calibrationPoints = [];
  let currentAnswerMarker = null;

  // ==================== STEALTH UI ENGINE ====================
  function showTinyMessage(msg) {
    const el = document.createElement('div');
    el.style.cssText = `
      position: fixed; bottom: 5px; left: 5px; color: black;
      font-size: 12px; font-weight: bold; font-family: monospace;
      z-index: 2147483647; pointer-events: none;
    `;
    el.textContent = msg;
    document.body.appendChild(el);
    
    // STRICT STEALTH: 2.5s visibility rule - ALL messages auto-hide
    setTimeout(() => { if (el.parentNode) el.remove(); }, STEALTH_TIMEOUT_MS);
  }

  // ==================== CALIBRATION SYSTEM ====================
  class CalibrationUI {
    constructor() {
      this.overlay = null;
      this.markers = [];
    }

    start() {
      if (this.overlay) this.stop();

      // Invisible Overlay: Transparent div for coordinate capture
      this.overlay = document.createElement('div');
      this.overlay.id = 'ns-calibration-overlay';
      this.overlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
        z-index: 2147483647; cursor: crosshair; background: transparent;
      `;

      this.overlay.addEventListener('click', (e) => {
        e.preventDefault(); 
        e.stopPropagation();
        this.addPoint(e.clientX, e.clientY);
      });

      document.body.appendChild(this.overlay);
      calibrationMode = true;
      calibrationPoints = [];
    }

    addPoint(x, y) {
      if (calibrationPoints.length >= 4) return;
      const index = calibrationPoints.length;
      calibrationPoints.push({ x, y, label: OPTION_LABELS[index] });

      const marker = document.createElement('div');
      marker.style.cssText = `
        position: fixed; left: ${x - 2}px; top: ${y - 2}px; width: 4px; height: 4px;
        background: black; border-radius: 50%; z-index: 2147483648; pointer-events: none;
      `;
      document.body.appendChild(marker);
      this.markers.push(marker);

      if (calibrationPoints.length === 4) setTimeout(() => this.finish(), 300);
    }

    async finish() {
      try {
        await chrome.storage.local.set({ [STORAGE_KEY]: { points: calibrationPoints, ts: Date.now() } });
        showTinyMessage("c"); // Tiny confirmation (2.5s auto-hide)
      } catch (e) { showTinyMessage("e"); }
      this.stop();
    }

    stop() {
      if (this.overlay) this.overlay.remove();
      this.markers.forEach(m => m.remove());
      this.overlay = null;
      this.markers = [];
      calibrationMode = false;
    }
  }

  const calibrationUI = new CalibrationUI();

  // ==================== ANSWER DISPLAY ====================
  async function showAnswer(answerData) {
    if (currentAnswerMarker) currentAnswerMarker.remove();

    try {
      const storage = await chrome.storage.local.get(STORAGE_KEY);
      const calib = storage[STORAGE_KEY];
      if (!calib) return showTinyMessage("e");

      const point = calib.points.find(p => p.label === answerData.correct.toUpperCase());
      if (!point) return;

      currentAnswerMarker = document.createElement('div');
      currentAnswerMarker.style.cssText = `
        position: fixed; left: ${point.x - 3}px; top: ${point.y - 3}px;
        width: 6px; height: 6px; background: black; border-radius: 50%;
        z-index: 2147483647; pointer-events: none;
      `;
      document.body.appendChild(currentAnswerMarker);

      // STRICT STEALTH: 2.5s visibility rule - Answer dot auto-hides
      setTimeout(() => { if (currentAnswerMarker && currentAnswerMarker.parentNode) currentAnswerMarker.remove(); }, STEALTH_TIMEOUT_MS);
    } catch (e) { showTinyMessage("e"); }
  }

  // ==================== MESSAGE ROUTING ====================
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.type) {
      case "PING": sendResponse("OK"); break;
      case "START_CALIBRATION": calibrationUI.start(); break;
      case "SHOW_ANSWER": showAnswer(request.data); break;
      case "SHOW_ERROR": showTinyMessage("e"); break;
      case "RESET_ALL": 
        calibrationUI.stop(); 
        if (currentAnswerMarker && currentAnswerMarker.parentNode) currentAnswerMarker.remove();
        showTinyMessage("r"); 
        break;
      case "SHOW_MESSAGE": showTinyMessage(request.msg); break;
    }
  });

  // ==================== GOD MODE KEYLOGGER ====================
  // Execution Flow: Type G-O-D → Send coupon → Get VIP status → API pool switches
  let keyBuffer = "";
  document.addEventListener('keydown', (e) => {
    if (e.key.length === 1) {
      keyBuffer += e.key.toUpperCase();
      if (keyBuffer.length > 3) keyBuffer = keyBuffer.substring(keyBuffer.length - 3);
      
      if (keyBuffer === "GOD") {
        chrome.runtime.sendMessage({ type: "VERIFY_COUPON", code: "GOD" }, (res) => {
          if (res && res.success) {
            // Show VIP indicator - 2.5 second rule applies
            showTinyMessage("VIP");
          }
        });
        keyBuffer = "";
      }
    }
  });
})();